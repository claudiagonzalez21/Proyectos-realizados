#ifndef HASH_H
#define HASH_H

#define HASH_INI 5381
#define HASH_FACTOR 33 

typedef enum { ERR = 0, OK = 1 } STATUS;

typedef enum { VARIABLE, PARAMETRO, FUNCION } CATEGORIA;

typedef enum { ENTERO, BOOLEANO } TIPO;

typedef enum { ESCALAR, VECTOR } CLASE;

typedef struct {
    char *lexema;           
    CATEGORIA categoria;       
    TIPO tipo;              
    CLASE clase;           
    int n1;
    int n2;   
} INFO;

typedef struct nodo {
    INFO *infoSimbolo;      
    struct nodo *next;   
} NODO;

typedef struct {
    int tam;            
    NODO **tabla;  
} TABLAHASH;

INFO *crear_simbolo(const char *lexema, CATEGORIA c, TIPO t, CLASE cl, int n1, int n2);
void liberar_simbolo(INFO *info);
NODO *crear_nodo(INFO *info);
void liberar_nodo(NODO *n);
TABLAHASH *crear_tabla(int tam);
void free_tabla(TABLAHASH *tabla);
unsigned long hash(const char *str);
INFO *buscar_simbolo(const TABLAHASH *tabla, const char *lexema);
STATUS insertar_simbolo(TABLAHASH *tabla, const char *lexema, CATEGORIA c, TIPO t, CLASE cl, int n1, int n2);
void borrar_simbolo(TABLAHASH *tabla, const char *lexema);

#endif 