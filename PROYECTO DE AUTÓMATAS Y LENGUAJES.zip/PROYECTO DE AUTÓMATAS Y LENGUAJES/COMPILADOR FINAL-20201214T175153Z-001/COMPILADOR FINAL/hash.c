#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "hash.h"

 /*Creamos una tabla hash como array de punteros a nodos 
 del tamaño que nos pasan como argumento*/

TABLAHASH *crear_tabla(int tam){
    TABLAHASH *tabla=NULL;

    tabla=(TABLAHASH*)malloc(sizeof(TABLAHASH));
    if(tabla == NULL){
        return NULL;
    }
    tabla->tabla = (NODO**)malloc(sizeof(NODO*));

    if (tabla->tabla == NULL) {
        free(tabla);
        return NULL;
    }

    tabla->tabla = (NODO**)calloc(tam, sizeof(NODO*));
    if (tabla->tabla == NULL) {
        free(tabla);
        return NULL;
    }

    tabla->tam = tam;
        
    return tabla;
}
void free_tabla(TABLAHASH* tabla){
    int i;
    NODO *n1=NULL, *sig=NULL;

    if(tabla == NULL){
        return;
    }
    if (tabla->tabla) {
    for (i = 0; i < (tabla->tam); i++) {
        n1 = tabla->tabla[i];
        while (n1) {
            sig = n1->next;
            liberar_nodo(n1);
            n1 = sig;
        }
    }
    free(tabla->tabla);
  }
  free(tabla);
    
}
NODO* crear_nodo(INFO* info){
    NODO *n;

    if(info == NULL){
        return NULL;
    }

    n = (NODO *)malloc(sizeof(NODO));
    if (n == NULL){
        return NULL;
    }
    n->infoSimbolo = info;
    n->next = NULL;

    return n;
}
void liberar_nodo(NODO* n){

    if(n==NULL){
        return;
    }
    liberar_simbolo(n->infoSimbolo);
    free(n);
}
INFO* crear_simbolo(const char* lexema, CATEGORIA c, TIPO t, CLASE cl, int n1, int n2){
    INFO *info=NULL;

    info = (INFO *) malloc(sizeof(INFO));

    if (info == NULL || lexema == NULL) { 
        return NULL;
    }
    /*duplicamos el string del lexema del simbolo*/
    info->lexema = strdup(lexema);
    if ((info->lexema) == NULL) {
        free(info);
        return NULL;
    }

    info->categoria = c;
    info->tipo = t;
    info->clase = cl;
    info->n1 = n1;
    info->n2 = n2;
    
    return info;
}
void liberar_simbolo(INFO* info){
    if (info == NULL) return;
    if (info->lexema) {
        free(info->lexema);
    }
    free(info);
}
INFO* buscar_simbolo(const TABLAHASH* tabla, const char* lexema){
    int posicion;    
    NODO *n=NULL;

    if (tabla == NULL || lexema == NULL) return NULL;
    posicion = hash(lexema) % tabla->tam; /*calculamos la pos en donde se encuentra*/
    n = tabla->tabla[posicion]; /*cogemos el nodo correspondiente*/

    if (n == NULL) return NULL;

    while (strcmp(n->infoSimbolo->lexema, lexema)){
        if (n->next == NULL) return NULL;
        n = n->next;
    }

    return n->infoSimbolo;
}
STATUS insertar_simbolo(TABLAHASH* tabla, const char* lexema, CATEGORIA c, TIPO t, CLASE cl, int n1, int n2){
    int pos;
    INFO *info = NULL;
    NODO *n = NULL;

    if (tabla == NULL|| lexema == NULL || buscar_simbolo(tabla, lexema)) return ERR;


    info = crear_simbolo(lexema, c, t, cl, n1, n2);
    if (!info) return ERR;

    n = crear_nodo(info);
    if (!n) {
        liberar_simbolo(info);
        return ERR;
    }

    pos = hash(lexema) % tabla->tam;
    n->next = tabla->tabla[pos];
    tabla->tabla[pos] = n;

    return OK;
}
void borrar_simbolo(TABLAHASH* tabla, const char* lexema){
    int pos;
    NODO *n=NULL, *anterior = NULL;

    pos = hash(lexema) % tabla->tam;
    n = tabla->tabla[pos];
    /*Si el simbolo no existe no se hace nada*/
    while (strcmp(n->infoSimbolo->lexema, lexema)) {
        anterior = n;
        n = n->next;
    }

    if (n == NULL) {
        return;
    } 

    if (anterior == NULL) {
        tabla->tabla[pos] = n->next;
    }

    else {
        anterior->next = n->next;
    }

    liberar_nodo(n);
    return;
}
/*función hash multiplicativa para cadenas*/
unsigned long hash(const char *str) {
    unsigned long h = HASH_INI;
    unsigned char *p;

    for (p = (unsigned char *) str; *p; p++) {
        h = h*HASH_FACTOR + *p;
    }

    return h; /*hash calculado por la cadena*/
}