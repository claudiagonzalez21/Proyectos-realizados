
Update public.orderdetail set price =( SELECT products.price/ (1.02^ (date_part('year',current_date)-date_part('year', public.orders.orderdate) ))*orderdetail.quantity
				FROM orders, products
				WHERE orderdetail.prod_id=products.prod_id AND orders.orderid=orderdetail.orderid);