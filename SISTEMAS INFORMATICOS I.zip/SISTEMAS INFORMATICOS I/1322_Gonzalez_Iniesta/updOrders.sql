DROP TRIGGER IF EXISTS updOrders ON orderdetail;
DROP TRIGGER IF EXISTS updOrders2 ON orderdetail;
CREATE OR REPLACE FUNCTION updOrders() RETURNS TRIGGER AS $$
    DECLARE
        precioT NUMERIC(7, 2); 
    BEGIN
        IF TG_OP = 'INSERT' THEN
            NEW.quantity = 1;
            NEW.price = (SELECT price FROM products WHERE NEW.prod_id = prod_id);

            UPDATE orders
            SET netamount = (netamount +(NEW.price * NEW.quantity)), orderdate = CURRENT_DATE,
                totalamount = netamount+(NEW.price * NEW.quantity) +((NEW.price * NEW.quantity)*orders.tax / 100)
            WHERE NEW.orderid = orders.orderid;
            RETURN NEW;

        ELSIF (TG_OP = 'UPDATE') THEN
            precioT =  (OLD.price * (NEW.quantity - OLD.quantity)); 
            OLD.quantity = NEW.quantity;
            
            UPDATE orders
            SET netamount = netamount + precioT, orderdate = CURRENT_DATE

            WHERE OLD.orderid = orders.orderid;

            UPDATE orders
            SET totalamount = netamount +(netamount*orders.tax / 100)
            WHERE OLD.orderid = orders.orderid;

            RETURN OLD;

        ELSIF (TG_OP = 'DELETE') THEN

            UPDATE orders
            SET netamount = (netamount - (OLD.price * OLD.quantity)), orderdate = CURRENT_DATE,
                totalamount = (netamount*orders.tax / 100)+1
            WHERE OLD.orderid = orders.orderid;	
            RETURN OLD;
        END IF;


    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER updOrders BEFORE INSERT ON orderdetail FOR EACH ROW EXECUTE PROCEDURE updOrders();
CREATE TRIGGER updOrders2 AFTER UPDATE OR DELETE ON orderdetail FOR EACH ROW EXECUTE PROCEDURE updOrders();
