DROP TRIGGER IF EXISTS updInventory ON orders;

CREATE OR REPLACE FUNCTION updInventory() RETURNS TRIGGER AS $$
DECLARE
	i RECORD;
BEGIN

   	IF (TG_OP = 'UPDATE' AND NEW.status = 'Paid') THEN
		OLD.orderdate = CURRENT_DATE;

		UPDATE inventory
		SET stock = stock - res.quantity, sales = sales + res.quantity
		FROM (
			SELECT prod_id, quantity
			FROM orders NATURAL JOIN orderdetail AS s1
			WHERE OLD.orderid = s1.orderid
			GROUP BY prod_id, quantity
		) AS res
		WHERE inventory.prod_id = res.prod_id;
		NEW.status='Processed';
 
        FOR i IN (SELECT prod_id FROM inventory WHERE stock < 1 and prod_id not in (select prod_id from alerts)) 
        LOOP
            INSERT INTO alerts (prod_id) VALUES (i.prod_id);
        END LOOP;

	END IF;

	RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER updInventory AFTER UPDATE ON orders FOR EACH ROW EXECUTE PROCEDURE updInventory();