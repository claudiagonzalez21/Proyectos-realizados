CREATE OR REPLACE FUNCTION setOrderAmount() RETURNS
    void
AS $$
    BEGIN
        UPDATE orders
        SET 
            netamount = s1.suma,
            totalamount = s1.suma +(s1.suma*(orders.tax / 100))
        FROM (
        SELECT orderid, sum(price*quantity) AS suma
        FROM orderdetail GROUP BY orderid) AS s1
        WHERE orders.orderid = s1.orderid;

END;
$$ LANGUAGE plpgsql;

select * from setOrderAmount()