select count(s1.cliente)
from ( 
    select distinct customerid as cliente
    from customers, orders
    where orderdate = 201504 and
          customers.customerid = orders.customerid and
          orders.totalamount > 100 ) as s1


explain select count(s1.cliente)
from ( 
    select distinct customerid as cliente
    from customers, orders
    where orderdate = 201504 and
          customers.customerid = orders.customerid and
          orders.totalamount > 100 ) as s1


create index i on orders(date_part('month', orders.orderdate));
explain select count(s1.cliente)
from ( 
    select distinct customerid as cliente
    from customers, orders
    where orderdate = 201504 and
          customers.customerid = orders.customerid and
          orders.totalamount > 100 ) as s1

drop index i;

create index i on orders(date_part('year', orders.orderdate));
explain select count(s1.cliente)
from ( 
    select distinct customerid as cliente
    from customers, orders
    where orderdate = 201504 and
          customers.customerid = orders.customerid and
          orders.totalamount > 100 ) as s1

drop index i;

create index i on orders(date_part('year', orders.orderdate), date_part('month', orders.orderdate));
explain select count(s1.cliente)
from ( 
    select distinct customerid as cliente
    from customers, orders
    where orderdate = 201504 and
          customers.customerid = orders.customerid and
          orders.totalamount > 100 ) as s1

drop index i;

create index i on orders(customerid);
explain select count(s1.cliente)
from ( 
    select distinct customerid as cliente
    from customers, orders
    where orderdate = 201504 and
          customers.customerid = orders.customerid and
          orders.totalamount > 100 ) as s1

drop index i;
