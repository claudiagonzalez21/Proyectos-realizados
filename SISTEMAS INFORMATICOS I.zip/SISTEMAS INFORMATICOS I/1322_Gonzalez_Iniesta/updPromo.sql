ALTER TABLE customers ADD column promo DECIMAL (10,0);

DROP TRIGGER IF EXISTS updPromo ON customers;
CREATE OR REPLACE FUNCTION updPromo() RETURNS TRIGGER AS $$

    BEGIN
    
        IF (TG_OP = 'UPDATE') THEN
            
            UPDATE orders
            SET totalamount = totalamount -(totalamount*(NEW.promo/100))
            WHERE customerid = NEW.customerid and orders.status IS NULL;
            perform pg_sleep(15);
            RETURN NEW;
        END IF;

    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER updPromo AFTER UPDATE ON customers FOR EACH ROW EXECUTE PROCEDURE updPromo();

UPDATE orders
SET status = NULL
WHERE orderid = 31502;

UPDATE orders
SET status = NULL
WHERE orderid = 100924;

UPDATE orders
SET status = NULL
WHERE orderid = 118208;
