				
create or replace function getTopMonths(int, int)
returns table(year int,month int, nprods int, namount float)
as $$
  DECLARE
    prods int = $1;
    totalamount int = $2;
    i record ;

  BEGIN
    FOR i IN (
      SELECT y, m, sum(o.totalamount) as importe, sum(quantity) as total
      FROM (
        SELECT date_part('year',orders.orderdate) as y, date_part('month',orders.orderdate) as m, orderid, orders.totalamount
      FROM orders
      GROUP BY y, m, orderid
      ORDER BY y, m
      )
      AS o JOIN orderdetail ON o.orderid = orderdetail.orderid
      GROUP BY y, m
    ) 
    LOOP
      IF i.importe > totalamount THEN
       year := i.y;
          month := i.m;
          namount := i.importe;
          nprods := i.total;
          RETURN NEXT;
      
       ELSIF i.total > prods THEN
          year := i.y;
          month := i.m;
          namount := i.importe;
          nprods := i.total;
          RETURN NEXT;
        END IF;
    END LOOP;
  END;
  $$ LANGUAGE 'plpgsql';
