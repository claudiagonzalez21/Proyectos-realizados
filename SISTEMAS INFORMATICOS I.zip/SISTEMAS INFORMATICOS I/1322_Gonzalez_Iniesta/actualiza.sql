--CREAR TABLA DE LANGUAGE/GENRES ETC Y UNIRLA A LA MOVIE PARA QUE NO PUEDAN METER UN DATO NO VALIDO
-- customers table:

ALTER TABLE public.customers ALTER COLUMN email SET NOT NULL;
ALTER TABLE public.customers ALTER COLUMN username SET NOT NULL;
ALTER TABLE public.customers ALTER COLUMN creditcard SET NOT NULL;
ALTER TABLE public.customers DROP COLUMN age;
ALTER TABLE public.customers DROP COLUMN firstname;
ALTER TABLE public.customers DROP COLUMN lastname;
ALTER TABLE public.customers DROP COLUMN address1;
ALTER TABLE public.customers DROP COLUMN city;
ALTER TABLE public.customers DROP COLUMN country;
ALTER TABLE public.customers DROP COLUMN region;
ALTER TABLE public.customers DROP COLUMN creditcardtype;
ALTER TABLE public.customers DROP COLUMN creditcardexpiration;
ALTER TABLE public.customers DROP COLUMN address2;
ALTER TABLE public.customers DROP COLUMN zip;
ALTER TABLE public.customers DROP COLUMN state;
ALTER TABLE public.customers DROP COLUMN phone;
ALTER TABLE public.customers DROP COLUMN gender;



delete from public.inventory where prod_id = NULL;
delete from orderdetail where prod_id = NULL;
--ACTORMOVIES
ALTER TABLE public.imdb_actormovies
ADD FOREIGN KEY (actorid) REFERENCES public.imdb_actors (actorid)  ;-- ON DELETE CASCADE;
ALTER TABLE public.imdb_actormovies
ADD FOREIGN KEY (movieid) REFERENCES public.imdb_movies (movieid)  ;-- ON DELETE CASCADE; 
ALTER TABLE public.imdb_actormovies ADD CONSTRAINT actormovies_id PRIMARY KEY(actorid, movieid);

--DIRECTORMOVIES
ALTER TABLE public.imdb_directormovies
ADD FOREIGN KEY (directorid) REFERENCES public.imdb_directors (directorid)  ;-- ON DELETE CASCADE; 
ALTER TABLE public.imdb_actormovies
ADD FOREIGN KEY (actorid) REFERENCES public.imdb_actors (actorid) ;-- ON DELETE CASCADE;

--MOVIES

ALTER TABLE public.imdb_moviecountries
ADD FOREIGN KEY (movieid) REFERENCES public.imdb_movies (movieid) ;-- ON DELETE CASCADE; 


ALTER TABLE public.imdb_moviegenres 
ADD FOREIGN KEY (movieid) REFERENCES public.imdb_movies (movieid) ;-- ON DELETE CASCADE; 

ALTER TABLE public.imdb_movielanguages 
ADD FOREIGN KEY (movieid) REFERENCES public.imdb_movies (movieid) ;-- ON DELETE CASCADE; 


--INVENTORY
ALTER TABLE public.inventory
ADD FOREIGN KEY (prod_id) REFERENCES public.products (prod_id) ;-- ON DELETE CASCADE; 
ALTER TABLE public.inventory ADD UNIQUE (prod_id);


--PRODUCTS

ALTER TABLE public.products
ADD FOREIGN KEY (movieid) REFERENCES public.imdb_movies (movieid) ;-- ON DELETE CASCADE;

--ORDERS

ALTER TABLE public.orders
ADD FOREIGN KEY (customerid) REFERENCES public.customers (customerid) ;-- ON DELETE CASCADE;
ALTER TABLE orders ALTER COLUMN netamount SET DEFAULT 0;
ALTER TABLE orders ALTER COLUMN totalamount SET DEFAULT 0;
ALTER TABLE orders ALTER COLUMN tax SET DEFAULT trunc(random() * 25);


--ORDER DETAIL
select prod_id,orderid,quantity into orderdetail_aux from public.orderdetail group by orderid, prod_id,quantity  having count(*) >1;
select prod_id,orderid into aux from public.orderdetail group by orderid, prod_id having count(*) >1;
DELETE FROM public.orderdetail WHERE (prod_id, orderid) in (select prod_id, orderid from aux);
INSERT INTO public.orderdetail SELECT prod_id, orderid, null, quantity FROM orderdetail_aux;
DROP TABLE orderdetail_aux;
DROP TABLE aux;


select prod_id,orderid,quantity into orderdetail_aux from public.orderdetail where prod_id is NULL group by orderid, prod_id,quantity ;
select prod_id,orderid into aux from public.orderdetail where prod_id is NULL group by orderid, prod_id ;
DELETE FROM public.orderdetail WHERE (prod_id, orderid) in (select prod_id, orderid from aux);
INSERT INTO public.orderdetail SELECT prod_id, orderid, null, quantity FROM orderdetail_aux;
DROP TABLE orderdetail_aux;
DROP TABLE aux;


delete from orderdetail where prod_id not in (select prod_id from products);
--ORDERDETAIL
ALTER TABLE public.orderdetail
ADD FOREIGN KEY (orderid) REFERENCES public.orders (orderid)  ;-- ON DELETE CASCADE; 
ALTER TABLE public.orderdetail
ADD FOREIGN KEY (prod_id) REFERENCES public.products (prod_id) ;-- ON DELETE CASCADE;
ALTER TABLE public.orderdetail ADD CONSTRAINT orderdetail_id PRIMARY KEY(orderid, prod_id);
select * from orderdetail;


-- SETPRICE:
--Update public.orderdetail set price =( SELECT products.price/ (1.02^ (date_part('year',current_date)-date_part('year', public.orders.orderdate) ))*orderdetail.quantity
--                                        FROM orders, products
--                                        WHERE orderdetail.prod_id=products.prod_id AND orders.orderid=orderdetail.orderid);
--
----SETORDERAMOUNT:	
--UPDATE orders SET netamount = s1.suma, totalamount = s1.suma +(s1.suma*orders.tax / 100)
--    FROM (
--    SELECT orderid, sum(price) AS suma
--    FROM orderdetail GROUP BY orderid) AS s1
--    WHERE orders.orderid = s1.orderid;

--MODIFICACIONES APARTADO F
--MOVIE COUNTRIES
CREATE TABLE movie_countries AS (SELECT DISTINCT country FROM imdb_moviecountries);
ALTER TABLE movie_countries ADD PRIMARY KEY (country);

--IMDB_MOVIE COUNTRIES
ALTER TABLE imdb_moviecountries ADD FOREIGN KEY(country) REFERENCES movie_countries(country) ;-- ON DELETE CASCADE;

--MOVIE GENRES
CREATE TABLE movie_genres AS (SELECT DISTINCT genre FROM imdb_moviegenres);
ALTER TABLE movie_genres ADD PRIMARY KEY (genre);

-- imdb_MOVIE GENRES
ALTER TABLE imdb_moviegenres ADD FOREIGN KEY(genre) REFERENCES movie_genres(genre) ;-- ON DELETE CASCADE;

--LANGUAGES
CREATE TABLE movie_languages AS (SELECT DISTINCT language FROM imdb_movielanguages);
ALTER TABLE movie_languages ADD PRIMARY KEY (language);

-- IMDB_LANGUAGES
ALTER TABLE imdb_movielanguages ADD FOREIGN KEY(language) REFERENCES movie_languages(language) ;-- ON DELETE CASCADE;

-- ALERTS
CREATE TABLE public.alerts (
    alertid integer NOT NULL,
    prod_id integer NOT NULL
);


ALTER TABLE public.alerts OWNER TO alumnodb;
CREATE SEQUENCE public.alerts_alertid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

ALTER TABLE public.alerts ADD PRIMARY KEY (alertid);

ALTER TABLE public.alerts_alertid_seq OWNER TO alumnodb;
ALTER SEQUENCE public.alerts_alertid_seq OWNED BY public.alerts.alertid;
ALTER TABLE public.alerts ADD FOREIGN KEY(prod_id) REFERENCES products(prod_id) ;-- ON DELETE CASCADE;
ALTER TABLE ONLY public.alerts ALTER COLUMN alertid SET DEFAULT nextval('public.alerts_alertid_seq'::regclass);
-- anade nuevo id a partir del ultimo usado
ALTER SEQUENCE customers_customerid_seq restart with 14094;
--
ALTER SEQUENCE orders_orderid_seq restart with 181791;

--NOS E SI HAY QUE HACER ESTO
ALTER SEQUENCE alerts_alertid_seq restart with 1;

--actualiza la tabla actor movies pq habia credits con -1
DELETE FROM IMDB_ACTORMOVIES WHERE CREDITSPOSITION < 0;