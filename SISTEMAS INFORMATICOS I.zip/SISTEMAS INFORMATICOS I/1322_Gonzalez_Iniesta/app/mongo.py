# -*- coding: utf-8 -*-
import pymongo
from pymongo import MongoClient




def getTopLife():
    lista = []
    client = pymongo.MongoClient("mongodb://localhost:27017/")
    db = client.si1
    ids=0
    resultado = db.topUSA.find({'title':{'$regex':'.*Life.*', '$options':'i'}, 'genres':{'$in':['Comedy']},  'year': '1997'}) #revisar lo de life

    for elem in resultado:    
        elem['id'] = ids
        ids += 1
        lista.append(elem)
        print(elem)

    print(lista)
    print("\n\n\n\n")

    return lista

def getTopWoody():
    lista = []
    client = pymongo.MongoClient("mongodb://localhost:27017/")
    db = client.si1
    ids=0
    for elem in db.topUSA.find({ 'directors': 'Allen, Woody',  'year': {'$in':['1990', '1991', '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999']}}):
        elem['id'] = ids
        ids += 1
        lista.append(elem)
    
    print(lista)
    print("\n\n\n\n")

    return lista

def getTopJim():
    lista = []
    client = pymongo.MongoClient("mongodb://localhost:27017/")
    db = client.si1
    ids=0
    for elem in db.topUSA.find({ 'actors': { '$all': ["Galecki, Johnny", "Parsons, Jim (II)"] } }):
        elem['id'] = ids
        ids += 1
        lista.append(elem)
    
    print(lista)
    print("\n\n\n\n")

    return lista
