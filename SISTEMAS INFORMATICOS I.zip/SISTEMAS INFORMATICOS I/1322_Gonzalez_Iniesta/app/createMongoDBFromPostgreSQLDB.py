 # -*- encoding: utf-8 -*-
import pymongo
from pymongo import MongoClient

import os
import sys, traceback
from sqlalchemy import create_engine
from sqlalchemy import Table, Column, Integer, String, MetaData, ForeignKey, text, and_, func
from sqlalchemy.sql import select, update, insert, delete

# configurar el motor de sqlalchemy
db_engine = create_engine("postgresql://alumnodb:alumnodb@localhost/si1", echo=False)
db_meta = MetaData(bind=db_engine)

def db_getTopUsa():
    try:
        db_conn = None
        db_conn = db_engine.connect()
        consulta = "select movieid, movietitle,year from imdb_movies where movieid in (\
                    select movieid from imdb_moviecountries where country ='USA')\
                    order by year desc limit 800;"
                    
        db_result = db_conn.execute(consulta).fetchall()

        peliculas = {}
        peliculas['peliculas'] = []
        for row in db_result:
            peli = {}
            peli['title'] = row[1]
            peli['genres'] = []
            # BYCLE DE GENRES
            peli['year'] = str(row[2])
            peli['directors'] = []
            peli['actors'] = []
            # Listas con un diccionario para cada peli
            peli['most_related_movies'] = []
            peli['related_movies'] = []


            consultaAct = "select imdb_actors.actorid, imdb_actors.actorname, creditsposition\
                            from imdb_actors, imdb_actormovies\
                            where\
                            imdb_actors.actorid = imdb_actormovies.actorid and\
                            imdb_actormovies.movieid = '{}' \
                            order by\
                            creditsposition ASC;".format(row[0])

            db_resultAct = db_conn.execute(consultaAct).fetchall()

            for r in db_resultAct:
                peli['actors'].append(str(r[1]))

            consultaDir = "select imdb_directors.directorid, imdb_directors.directorname\
                            from imdb_directors, imdb_directormovies\
                            where\
                            imdb_directors.directorid = imdb_directormovies.directorid\
                            and imdb_directormovies.movieid = '{}';".format(row[0])

            db_resultDir = db_conn.execute(consultaDir).fetchall()

            for r in db_resultDir:
                peli['directors'].append(str(r[1]))

            consultaCat = "select genre from imdb_moviegenres\
                            where imdb_moviegenres.movieid = '{}'\
                            order by genre desc;".format(row[0])
            db_resultCat = db_conn.execute(consultaCat).fetchall()

            for r in db_resultCat:
                peli['genres'].append(str(r[0]))

            peliculas['peliculas'].append(peli)
        

        db_conn.close()

        # Para cada pelicula buscamos entre topUSA las relacionadas
        for pelicula in peliculas['peliculas']:
            for peli2 in peliculas['peliculas']:
                # Si la peli con la que vamos a comprar no es la actual
                if peli2 is not pelicula:
                    # Si la peli actual no está ya en las relacionadas de la peli2
                    if pelicula not in peli2['most_related_movies']:
                        if pelicula not in peli2['related_movies']:
                            flag = 0
                            flag2 = 0
                            # Comprobamos que peli2 tiene los generos de pelicula
                            for g in pelicula['genres']:
                                if g not in peli2['genres']:
                                    flag = 1
                                # Contabilizamos en flag2 el numero de generos comunes
                                else:
                                    flag2 += 1
                            # Si peli2 tiene todos los generos de pelicula es most_related
                            if flag == 0:
                                p = {'title': peli2['title'], 'year': peli2['year']}
                                pelicula['most_related_movies'].append(p)
                            else:
                                # Si no tiene todos comprobamos si hay mas de 1 genero
                                # y si el numero de generos que coincide es la mitad
                                # en ese caso e suna related
                                if len(pelicula['genres']) > 1:
                                    mitad = len(pelicula['genres'])/2
                                    if flag2 == mitad:  # Hemos entendido en el enunciado que tenia que ser el 50% exacto.
                                        p = {'title': peli2['title'], 'year': peli2['year']}
                                        pelicula['related_movies'].append(p)
                                        
        return peliculas['peliculas']
    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return None


def mongo():
    client = pymongo.MongoClient("mongodb://localhost:27017/")

    # creamos base de datos si1
    db = client.si1

    # creamos la coleccion topUSA
    if db.topUSA:
        db.topUSA.drop()
    coleccion1 = db.topUSA

    lista = db_getTopUsa()

    resultado = coleccion1.insert_many(lista)
    for l in lista:

        if l['title'] == "Big Bang Theory (2006)":
            print(l['actors'])
    print(coleccion1.count_documents({}))  # para saber cuantos documentos hay

    client.close()


if __name__ == "__main__":
    mongo()




    