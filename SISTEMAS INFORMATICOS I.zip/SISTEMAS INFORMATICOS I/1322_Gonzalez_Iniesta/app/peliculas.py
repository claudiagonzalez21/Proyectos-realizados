# -*- coding: utf-8 -*-

class peliculas:

def __init__(self, title, genres, year, directors, actors, most_related_movies, related_movies):
    self.title = title
    self.genres = genres
    self.year = year
    self.directors = directors
    self.actors = actors
    self.most_related_movies = most_related_movies
    self.related_movies = related_movies

def toDBCollection(self):
    return {
        "title":self.title,
        "genres":self.genres,
        "year":self.year,
        
    }