#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from app import app, database, mongo
from flask import render_template, request, url_for, redirect, session, make_response
import json
import os
import sys
import random
import hashlib
from datetime import date
from datetime import datetime
import time

@app.route('/')
@app.route('/index', methods=['GET', 'POST'])
def index():
    print (url_for('static', filename='estilo.css'), file=sys.stderr)
    ruta_catalogue = os.path.join(app.root_path,'catalogue/catalogue.json')
    catalogue_data = {}
    catalogue = {}
    catalogue['peliculas'] = []
    catalogue = database.db_catalogue()
    catalogue_data['peliculas'] = catalogue['peliculas']
    f = open(ruta_catalogue,"w")
    json.dump(catalogue_data, f, indent=4)
    f.close()
    currentdate=datetime.now()

    if not 'carrito' in session:
        session['carrito'] = []

    # En caso de que haya un usuario loggedIn y no se haya creado el
    # carrito llamamos a esa funcion que nos devuelve el orderid creado
    # para el user con este date
    
    session['categorias'] = database.db_categories()
        
    if 'categorias' in request.form: 
        cat = request.form.get('categorias').lower()
        catalogue_search = []
        for item in catalogue['peliculas']:
            for itemC in item['categoria']:
                if itemC.lower() == cat:
                    catalogue_search.append(item)
        if cat != "categorias":
            if catalogue_search:
                return render_template('index.html', title = "Home", movies=catalogue_search, error="", topVentas=database.db_getTopVentas(int(currentdate.year-2), int(currentdate.year)))
            else:
                return render_template('index.html', title = "Home", movies=catalogue['peliculas'], error= "No hemos encontrado ninguna peli de esa categoria", topVentas=database.db_getTopVentas(int(currentdate.year-2), int(currentdate.year)))
    if 'Search' in request.form:
        search = request.form.get('Search').lower()
        catalogue_search = []
        if search == " ":
            return render_template('index.html', title = "Home", movies=catalogue['peliculas'],error="", topVentas=database.db_getTopVentas(int(currentdate.year-2), int(currentdate.year)))
        
        for item in catalogue_data['peliculas']:
            if item.get('titulo').lower() == search:
                catalogue_search.append(item)
                return redirect(url_for('film', id=item.get('id')))
            elif item.get('director').lower() == search:
                catalogue_search.append(item)
            elif item.get('año').lower() == search:
                catalogue_search.append(item)
            else:
                for actor in item['actores']:
                    if actor.get('nombre').lower() == search:
                        catalogue_search.append(item)
                    if actor.get('personaje').lower() == search:
                        catalogue_search.append(item)
                for itemC in item['categoria']:
                    if itemC.lower() == search:
                        catalogue_search.append(item)
        if catalogue_search:
            return render_template('index.html', title = "Home", movies=catalogue_search, error="", topVentas=database.db_getTopVentas(int(currentdate.year-2), int(currentdate.year)))
        else:
            return render_template('index.html', title = "Home", movies=catalogue['peliculas'], error= "No hemos encontrado ninguna peli con esas características", topVentas=database.db_getTopVentas(currentdate.year-2, currentdate.year))
    return render_template('index.html', title = "Home", movies=catalogue['peliculas'],error="", topVentas=database.db_getTopVentas(int(currentdate.year-2), int(currentdate.year)))

@app.route('/login', methods=['GET', 'POST'])
def login():
    # doc sobre request object en http://flask.pocoo.org/docs/1.0/api/#incoming-request-data
    
    if request.method=='POST':

        if database.db_login(request.form['username'], request.form['password']) is True: #si existe el usuario
            nombre = request.form['username']
            session['usuario'] = nombre
            session['password'] = request.form['password']
            session.modified=True
            aux = database.db_infouser(nombre)
            if aux:
                session['userid'] = aux[0][0]
                session['email'] = aux[0][1]
                session['tarjeta'] = aux[0][2]
                # 3 username 4 password
                session['saldo'] = str(aux[0][5])

            # Creamos un carrito al user en la bdd en caso de que no tuviese ya uno
            orderId = database.db_oldCart(session['userid'])

            if orderId is None:
                session['orderId'] = database.db_newCart(session['userid'])
                aux = None
            else:
                session['orderId'] = orderId
                aux = database.db_getCart(orderId)
                session['totalamount'] = database.getTotalAmount(orderId)[0][0]

            # En caso de que antes de iniciar sesion tuviese un carrito con cosas:
            if 'carrito' in session:
                for peli in session['carrito']:
                    hay = False
                    if aux:
                        for p in aux:
                            if peli['id'] == p['id']:
                                hay = True
                                cant = int(peli['cantidad']) + int(p['cantidad'])
                                res = database.db_updateCart(peli['id'],session['orderId'],cant)
                    if hay is False:
                        res = database.db_addCart(peli['id'],session['orderId'])
                        res = database.db_updateCart(peli['id'],session['orderId'],peli['cantidad'])
                session['totalamount'] = database.getTotalAmount(session['orderId'])[0][0]
            if aux:
                for peli in aux:
                    hay = False
                    for p in session['carrito']:
                        if peli['id'] == p['id']:
                            hay = True
                            p['cantidad'] = peli['cantidad'] + p['cantidad']
                    if hay is False:
                        session['carrito'].append(peli)

            return redirect(url_for('index'))           
        else:
            return render_template('login.html', title = "Sign In", error = "Contraseña incorrecta", user="")

    
    else:
        user = getCookie()
        return render_template('login.html', title="Sign in", error ="", user = user)



@app.route('/registro', methods=['GET', 'POST'])
def registro():

    if request.method == "POST":
        nombre = request.form.get('username')
        contra = request.form.get('password')
        email = request.form.get('email')
        tarjeta = request.form.get('tarjeta')
        saldo = random.randrange(100)
        saldo = "{:.2f}".format(saldo)

        if database.existsUser(nombre) == True: #si existe el usuario
            return render_template('registro.html', title="Sign Up", error = "Ya existe ese usuario") 

        userid = database.db_registro(nombre, contra, email, tarjeta, saldo)
       
        if userid:
            uid = userid[0][0]
            session['usuario'] = nombre
            session['userid'] = uid
            session['email'] = email
            session['password'] = contra
            session['tarjeta'] = tarjeta
            session['saldo'] = str(saldo)
            session['orderId'] = database.db_newCart(session['userid'])
            session.modified=True
            return redirect(url_for('index'))
        return redirect(url_for('login'))

    return render_template('registro.html', title="Sign Up", error = "")



@app.route('/logout', methods=['GET', 'POST'])
def logout():
    response = setCookie(session['usuario'])
    session.pop('usuario', None)
    session.pop('password',None)
    session.pop('email',None)
    session.pop('tarjeta',None)
    session.pop('saldo',None)
    session.pop('carrito',None)
    session.pop('compras', None)
    session.pop('orderId',None)
    session.pop('userid',None)
    session.pop('totalamount',None)
    return response


@app.route('/film/<int:id>', methods=['GET', 'POST'])
def film(id):
    print (url_for('static', filename='estilo.css'), file=sys.stderr)
   
    catalogue_data = open(os.path.join(app.root_path,'catalogue/catalogue.json'), encoding="utf-8").read()
    catalogue = json.loads(catalogue_data)

    # Si le pulsan a aniadir al carrito
    if request.form.get("Boton") == "Añadir al carrito":
        # Miramos si ya teniamos esa peli
        for peli in session['carrito']:
            if peli.get('id') == id:
                # Si ya la teníamos modificamos la cantidad
                cant = int(peli['cantidad']) + 1
                peli['cantidad'] = str(cant)
                # Si el usuario ha iniciado sesion y ya tiene order en bdd se actualiza
                if 'usuario' in session and 'orderId' in session:
                    res = database.db_updateCart(id,session['orderId'],peli['cantidad'])
                    session['totalamount'] = database.getTotalAmount(session['orderId'])[0][0]
                return redirect(url_for('carrito'))
    # Recorremos todas las pelis del catalogo     
    for peli in catalogue['peliculas']:
        # Si el id coincide
        if peli.get('id') == id:
            # Si han solicitado aniadir al carrito y no estaba en el carrito ya guardada
            # Es pq es la primera vez que se añade y su cantidad es 1
            if request.form.get("Boton") == "Añadir al carrito":
                peli['cantidad'] = 1
                session['carrito'].append(peli)
                # En caso de que el usuario esté logged in
                if 'usuario' in session:
                    if 'orderId' in session:
                        # En caso de que ya exista el order de este user se ñade un orderdetail
                        res = database.db_addCart(id,session['orderId'])
                        session['totalamount'] = database.getTotalAmount(session['orderId'])[0][0]
                return redirect(url_for('carrito'))
            return render_template('film.html', title = peli['titulo'], movie = peli)
    return redirect(url_for('index'))

@app.route('/carrito', methods=['GET', 'POST'])
def carrito():
    print (url_for('static', filename='estilo.css'), file=sys.stderr)
    precio = 0
    aux = 0
    date = datetime.now().strftime('%d/%m/%Y Hora: %Hh')
   
    datosCompra = {}
    todasCompras = {}
    todasCompras['compras'] = []
    elementosComprados = 0
    if 'usuario' in session:

        session['totalamount'] = database.getTotalAmount(session['orderId'])[0][0]

        if session['totalamount']:

            precio =float(session['totalamount'])
    else:
        for peli in session['carrito']:
            precioPeli = float(peli.get('precio'))*float(peli.get('cantidad'))
            precio+= precioPeli

    if request.form.get("Boton") == "Realizar Pago":
        if 'usuario' in session:#COMPROBAR QUE ESTÁ REGISTRADO
            username = session['usuario']
            if float(session['saldo']) >= precio:
                #Restamos lo que nos hemos gastado del saldo 
                session['saldo'] = str("{:.2f}".format(float(session['saldo'])-precio)) 
                s_aux = "{:.0f}".format(float(session['saldo'])-precio)
               
                newId = database.db_compra(session['orderId'], username,session['userid'], s_aux)
                # Vaciamos el carrito
                session['carrito'] = []
                session['orderId'] = newId
                session['totalamount'] = 0
                #craer nuevo orderid
                precio = 0
            else:
                return render_template('carrito.html', title = "Carrito", movies = session['carrito'],precio = precio, error="Saldo insuficiente")
        else:
            return render_template('carrito.html', title = "Carrito", movies = session['carrito'],precio = precio, error="Debes estar registrado")
    
    return render_template('carrito.html', title = "Carrito", movies = session['carrito'],precio = precio,error="")

@app.route('/eliminarPelicula/<int:id>', methods=['GET', 'POST'])
def eliminarPelicula(id):
    print (url_for('static', filename='estilo.css'), file=sys.stderr)
    for peli in session['carrito']:
        if peli.get('id') == id:
            session['carrito'].remove(peli)
            if 'usuario' in session:
                username = session['usuario']
                database.db_eliminarPelicula(session['orderId'], id)
                session['totalamount'] = database.getTotalAmount(session['orderId'])[0][0]
    return redirect(url_for('carrito'))

@app.route('/aniadirPelicula/<int:id>', methods=['GET', 'POST'])
def aniadirPelicula(id):
    print (url_for('static', filename='estilo.css'), file=sys.stderr)

    catalogue_data = open(os.path.join(app.root_path,'catalogue/catalogue.json'), encoding="utf-8").read()
    catalogue = json.loads(catalogue_data)

    for peli in session['carrito']:
        if peli.get('id') == id:
            peli['cantidad'] =request.form.get('cantidad')

            if 'usuario' in session and 'orderId' in session:
                res = database.db_updateCart(id,session['orderId'],peli['cantidad'])
                session['totalamount'] = database.getTotalAmount(session['orderId'])[0][0]
            return redirect(url_for('carrito'))
    
    for peli in catalogue['peliculas']:
        if peli.get('id') == id:
            peli['cantidad'] = 1
            session['carrito'].append(peli)
        # Si el usuario está iniciado sesion metemos en la bdd
        # Creo q hay que pasar el carrito en vez del id
            if 'usuario' in session:
                if 'orderId' in session:
                    # En caso de que ya exista el order de este user
                    res = database.db_addCart(id,session['orderId'])
    session['totalamount'] = database.getTotalAmount(session['orderId'])[0][0]

    return redirect(url_for('carrito'))


@app.route('/usuario', methods=['GET', 'POST'])
def usuario():
    print (url_for('static', filename='estilo.css'), file=sys.stderr)
    compras = {}
    username = session['usuario']
    catalogue_data = []
    catalogue = {}
    # Leemos el historial de compras y lo guardamos en la variable compras, compras['compras'] es la
    # que tiene los datos que nos interesan
    # direc = os.path.join("usuarios/",username+"/historial.json")
    # compras_data = open(direc, encoding="utf-8").read()
    ruta_catalogue = os.path.join(app.root_path,'catalogue/catalogue.json')
    catalogue = open(ruta_catalogue,encoding="utf-8")
    currentdate=datetime.now()
    compras = database.db_historial(session['userid'])
    listaAuxPelis = []
    catalogue_data = json.load(catalogue)

    for compra in compras['compras']:
        listaAuxPelis = []
        for peliId in compra['peliculas']:
            pelicula = {}
            for peli in catalogue_data["peliculas"]:
                pelicula = {}
                if peliId['id'] == peli['id']:
                    aux = True
                    pelicula['id'] = peliId['id']
                    pelicula['poster'] = peli['poster']

            if 'id' not in pelicula:
                pelicula['poster'] = None
            
            pelicula['titulo'] = peliId['titulo']
            pelicula['cantidad'] = peliId['cantidad']
            
            listaAuxPelis.append(pelicula)
        compra['peliculas'] = listaAuxPelis


    if 'saldo' in request.form:
        saldoSum = float(request.form.get('saldo'))
        if saldoSum < 0: #Si quitamos este if deja restar el saldo
            return render_template('usuario.html', title=username,compras=compras['compras'],error="Solo puedes aumentar el saldo")
        saldoAn = float(session['saldo'])
        saldo = saldoAn + saldoSum
        saldo = "{:.2f}".format(saldo)
        s_aux = "{:.0f}".format(saldoAn + saldoSum)
        if database.db_actualizasaldo(username, int(s_aux)):
            session['saldo'] = str(saldo)
        else:
             return render_template('usuario.html', title=username ,compras=compras['compras'], error="No se ha podido actualizar tu saldo")

    return render_template('usuario.html', title = username,compras=compras['compras'], error="")


@app.route('/usuariosConectados', methods=['GET', 'POST'])
def usuariosConectados():
    if request.method == "GET":
        respuesta = random.randint(1,1000)
        return  str(respuesta)
    else:
        return "0"

@app.route('/getCookie', methods=['GET','POST'])
def getCookie():
    user = request.cookies.get('usuario')
    if user is not None:
        return user
    else:
        return ""
    
@app.route('/setCookie/<string:user>/', methods=['GET','POST'])
def setCookie(user):
    response = make_response(redirect(url_for('index')))
    response.set_cookie('usuario',user)
    return response

# Ejemplo de union con base de datos
@app.route('/list-of-movies')
def listOfMovies():
    movies_1949 = database.db_listOfMovies1949()
    return render_template('list_movies.html', title = "Movies from Postgres Database", movies_1949 = movies_1949)

@app.route('/getTopMonths', methods=['GET', 'POST'])
def getTopMonths():
    
    return render_template('topMonths.html', title = "", topMonths=database.db_getTopMonths(19000, 320000))


@app.route('/getTopUSA', methods=['GET', 'POST'])
def getTopUSA():

    return render_template('topUSA.html', title = "", topUSALife=mongo.getTopLife(), topUSAWoody=mongo.getTopWoody(), topUSAJim=mongo.getTopJim())


@app.route('/borraCliente', methods=['POST', 'GET'])
def borraCliente():
    if 'customerid' in request.form:
        customerid = request.form["customerid"]
        bSQL       = request.form["txnSQL"]
        bCommit = "bCommit" in request.form
        bFallo  = "bFallo"  in request.form
        duerme  = request.form["duerme"]
        if database.customerExists(customerid) is False:
            dbr = []
            dbr.append("No puedes Borrar un Usuario que no existe")
        else:
            dbr = database.delCustomer(customerid, bFallo, bSQL=='1', int(duerme), bCommit)
        return render_template('borraCliente.html', dbr=dbr)
    else:
        return render_template('borraCliente.html')

    
@app.route('/listaClientesMes', methods=['GET', 'POST'])
def listaClientesMes():
    if 'fecha' in request.form:
        fecha  = request.form['fecha']
        mes    = request.form['mes']
        anio   = request.form['anio']
        umbral = request.form['minimo']
        intervalo = request.form['intervalo']
        use_prepare = 'prepare'  in request.form
        break0 = 'break0' in request.form
        niter  = request.form['iter']
        # connect fuera para comparar tiempos con más precisión
        db_conn = database.dbConnect()
        t0=round(time.time() * 1000)
        dbr = database.getListaCliMes(db_conn, mes, anio, int(umbral), int(intervalo), use_prepare, break0, int(niter))
        t1=round(time.time() * 1000)
        database.dbCloseConnect(db_conn)

        return render_template('listaClientesMes.html',
            fecha = fecha,
            mes   = mes,
            anio  = anio,
            umbral = int(umbral),
            intervalo = int(intervalo),
            use_prepare = use_prepare,
            break0 = break0,
            tiempo = str(int(t1-t0)),
            dbr=dbr
           )
    else:
        return render_template('listaClientesMes.html')
