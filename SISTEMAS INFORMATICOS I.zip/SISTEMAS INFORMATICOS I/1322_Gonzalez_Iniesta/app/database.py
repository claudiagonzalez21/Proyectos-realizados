# -*- coding: utf-8 -*-

import os
import sys, traceback
from sqlalchemy import create_engine
from sqlalchemy import Table, Column, Integer, String, MetaData, ForeignKey, text, and_, func
from sqlalchemy.sql import select, update, insert, delete
from datetime import timezone
import time

# configurar el motor de sqlalchemy
db_engine = create_engine("postgresql://alumnodb:alumnodb@localhost/si1", echo=False)
db_engine2 = create_engine("postgresql://alumnodb:alumnodb@localhost/si1", echo=False, execution_options={"autocommit":False})
db_meta = MetaData(bind=db_engine)
# cargar una tabla
db_table_movies = Table('imdb_movies', db_meta, autoload=True, autoload_with=db_engine)
db_table_customers = Table('customers', db_meta, autoload=True, autoload_with=db_engine)
db_table_orderdetail = Table('orderdetail', db_meta, autoload=True, autoload_with=db_engine)
db_table_orders = Table('orders', db_meta, autoload=True, autoload_with=db_engine)
db_table_products = Table('products', db_meta, autoload=True, autoload_with=db_engine)


def db_listOfMovies1949():
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
        
        # Seleccionar las peliculas del anno 1949
        #db_movies_1949 = select([db_table_movies])</br></br>.where(text("year = '1949'"))
        #db_result = db_conn.execute(db_movies_1949)
       # El profe recomienda usar la linea de debajo!
       # hay que tener cuidado pq al hacerla nosotros tienen menos seguridad
       # EN los enlaces del enunciado cambiar latest por 13
       # El + interesante es el enlace del result proxy (13)
        db_result = db_conn.execute("Select * from imdb_movies where year = '1949'")
        
        db_conn.close()
        
        return  list(db_result)
    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return 'Something is broken'


def db_categories():
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
        lista =  []
        aux = {}
        db_result = db_conn.execute("Select distinct genre from imdb_moviegenres;").fetchall()
        
        db_conn.close()
        
        for row in db_result:
            aux = {}
            aux['cat'] = row[0]
            lista.append(aux)

        return  lista
    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return 'Something is broken'

def db_stock(peliId):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()

        # Cogemos el prod_id correspondiente a la peli que hemos metido
        consultaGetProd = "Select prod_id from products where movieid='{}'".format(peliId)
        db_resultProdId = db_conn.execute(consultaGetProd).fetchall()
        prodId = db_resultProdId[0][0]
        
        # Cogemos el stock del inventory
        consulta = "Select stock from inventory where prod_id = '{}'".format(prodId)       
        stock = db_conn.execute(consulta).fetchall()
     
        db_conn.close()
        return list(stock)

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return 'Something is broken'

def db_catalogue():
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
        consulta = "select imdb_movies.movieid, movietitle, year, directorname\
                    from imdb_movies,imdb_directors,imdb_directormovies\
                    where imdb_movies.movieid = imdb_directormovies.movieid and\
                    imdb_directors.directorid = imdb_directormovies.directorid\
                    order by imdb_movies.movieid asc limit 5;"
                    

        db_result = db_conn.execute(consulta).fetchall()
       
        
        peliculas = {}
        peliculas['peliculas'] = []
        peli = {}
        actor = {}
       
        for row in db_result:
            peli = {}
            peli['id'] = row[0]
            peli['titulo'] = row[1]
            peli['poster'] ="../static/imagenes/"+ str(row[0])+".jpg"
            peli['director'] = row[3]
            peli['año'] = str(row[2])
            peli['categoria'] = []
            peli['actores'] = []
            peli['stock'] = []
            listaStock = db_stock(row[0])
            if listaStock:
                st = int(listaStock[0][0])
            else:
                st = 10
            # En caso de que haya poco stock solo se llega hasta el max
            # si el stock es alto solo dejamos coger 15 peliculas como max
            if st < 10:
                r = st
            else:
                r = 15
            for i in range(1,r):
                aux = {}
                aux['st'] = i
                peli['stock'].append(aux)
            #Hacer dict con precio tipo peli (description)
            consultaPri = "Select price from products where products.movieid ='{}' limit 1;".format(row[0])
            db_resultPri = db_conn.execute(consultaPri).fetchall()
            peli['precio'] = str(db_resultPri[0][0])

            consultaCat = "select movie_genres.genre from imdb_moviegenres, movie_genres\
                            where movie_genres.genre = imdb_moviegenres.genre and imdb_moviegenres.movieid = '{}'\
                            order by movie_genres.genre desc;".format(row[0])
            db_resultCat = db_conn.execute(consultaCat).fetchall()

            for r in db_resultCat:
                peli['categoria'].append(r[0])

            consultaAct = "select imdb_actors.actorid, imdb_actors.actorname, character, creditsposition\
                            from imdb_actors, imdb_actormovies\
                            where imdb_actors.actorid = imdb_actormovies.actorid and\
                            imdb_actormovies.movieid = '{}' order by creditsposition ASC limit 3;".format(row[0])
            db_resultAct = db_conn.execute(consultaAct).fetchall()

            for r in db_resultAct:
                actor = {}
                actor['nombre'] = r[1]
                actor['personaje'] = r[2]
                actor['foto'] = "../static/imagenes/"+str(r[0])+".jpg"
                peli['actores'].append(actor)

            peliculas['peliculas'].append(peli)


        db_conn.close()

        return peliculas

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return 'Something is broken'
    

def db_getTopVentas(year1, year2):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
        consulta = "select * from getTopVentas({}, {})".format(int(year1), format(int(year2)))

        db_result = db_conn.execute(consulta)
        db_conn.close()
        
        tabla = []

        for row in db_result:
            tabla.append({
                'year': row[0],
                'titulo': row[1],
                'ventas': row[2]
            })

        return tabla

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return 'Something is broken'
    
def db_getTopMonths(n1, n2):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
        consulta = "select * from getTopMonths({}, {})".format(int(n1), format(int(n2)))

        db_result = db_conn.execute(consulta)
        db_conn.close()
        
        tabla = []

        for row in db_result:
            tabla.append({
                'year': row[0],
                'month': row[1],
                'nprods': row[2],
                'namount': row[3]
            })

        return tabla

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return 'Something is broken'

def db_registro(username, password, email, tarjeta, saldo):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()

        consulta = "insert into customers (username, email, password, creditcard,income) values ('{}', '{}', '{}', '{}', {})".format(username, email, password, tarjeta, saldo)  
        consulta2 = "select * from customers where username ='{}' and password = '{}'".format(username, password)      
        db_conn.execute(consulta)
        db_result = db_conn.execute(consulta2)
        res = db_result.fetchall()
        db_conn.close()

        if res:
            return list(db_result)
        else:
            return None
          
    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return None


def existsUser(username):
    try:
        db_conn = None
        db_conn = db_engine.connect()

        db_user_exists = "select customerid from customers where username = '" + username + "'"

        db_result = db_conn.execute(db_user_exists)

        db_conn.close()

        if db_result.fetchone() is not None:
            return True
        else:
            return False
    except:
        if db_conn is not None:
            db_conn.close()
        return 'Something is broken'


def db_login(username, password):
    try:
        db_conn = None
        db_conn = db_engine.connect()

        query = "select * from public.customers where username = " + "'" + username + "'" + ";"
        
        db_result = db_conn.execute(query)

        # si existe un usuario
        if db_result.fetchone() is not None:
            #comprobar contrasena
            query2 = "select customerid from customers where username = '" + username + "' and password = '" + password + "';"
            db_result = db_conn.execute(query2)

            res = db_result.fetchone()
            db_conn.close()

            if res:
                return True
            else:
                return False
        else:
            return False

        return list(db_result)
    except:
        if db_conn is not None:
            db_conn.close()
        return 'Something is broken'

def db_infouser(username):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
            
        consulta = "select * from customers where username = '" + username + "';"
            
        db_result = db_conn.execute(consulta).fetchall()
        db_conn.close()

        return list(db_result)

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return 'Something is broken'

def db_actualizasaldo(username, saldo):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
            
        consulta = "update customers set income = '{}' where username = '{}'".format(saldo, username)
        db_result = db_conn.execute(consulta)

        db_conn.close()

        return True

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return 'Something is broken'

def db_historial(userid):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
        compras = {}

        pelicula = {}
        datos_compra = {}
        compras['compras'] = []
        datos_compra['peliculas'] = []
        datos_compra['numero'] = 0
        elem = 0
        # Orders de un user
        orders = "Select orderid,orderdate,totalamount, status from orders where customerid='{}' and status != '' order by orderdate desc limit 10".format(userid)
        db_resultOrders = db_conn.execute(orders)
        for row in db_resultOrders:
            elem=0
            datos_compra = {}
            datos_compra['peliculas'] = []
            datos_compra['numero'] = row[0] # Id de la compra
            datos_compra['fecha'] = row[1]
            datos_compra['precio'] = row[2]
            datos_compra['estado'] = row[3]

            consulta = "Select distinct imdb_movies.movieid, sum(orderdetail.quantity) as q, imdb_movies.movietitle\
                        from products, orderdetail,imdb_movies\
                        where imdb_movies.movieid = products.movieid and\
                        orderdetail.prod_id = products.prod_id and orderid ='{}' group by imdb_movies.movieid limit 10 ".format(row[0])
            db_result = db_conn.execute(consulta)

            for i in db_result:
                pelicula = {}
                pelicula['id'] = i[0]
                pelicula['cantidad'] = i[1]
                pelicula['titulo'] = i[2]
                elem += 1
                datos_compra['peliculas'].append(pelicula)
            datos_compra['elementos'] = elem
            compras['compras'].append(datos_compra)

        db_conn.close()

        return compras
    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return None

def db_oldCart(userId):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
#
        #Creamos una nueva entrada en orders
        consulta = "select orderid from orders where customerid = '{}' and status = NULL".format(userId)       
        db_conn.execute(consulta)
        # COgemos el orderid que acabamos de crear
        consultaGetOrder = "Select orderid from orders where customerid='{}' and orderdate =CURRENT_DATE order by orderid desc limit 1".format(userId)
        db_resultOrderId = db_conn.execute(consultaGetOrder).fetchall()
        # REVISAR COMO HACER ESE IF
        if list(db_resultOrderId)[0][0]:
            orderId = list(db_resultOrderId)[0][0]

            return orderId
        else:
            return None

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return None

def db_newCart(userId):

    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
#
        #Creamos una nueva entrada en orders
        consulta = "insert into orders(orderdate,customerid,status)values(CURRENT_DATE,'{}',NULL)".format(userId)       
        db_conn.execute(consulta)
        # COgemos el orderid que acabamos de crear
        consultaGetOrder = "Select orderid from orders where customerid='{}' and orderdate =CURRENT_DATE order by orderid desc limit 1".format(userId)
        db_resultOrderId = db_conn.execute(consultaGetOrder).fetchall()
        orderId = db_resultOrderId[0][0]
        return orderId

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return None



def db_addCart(peliId,orderId):

    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()

        # Cogemos el prod_id correspondiente a la peli que hemos metido
        consultaGetProd = "Select prod_id from products where movieid='{}'".format(peliId)
        db_resultProdId = db_conn.execute(consultaGetProd).fetchall()
        prodId = db_resultProdId[0][0]
        
        # Creamos una nueva entrada de orderdetail
        consulta = "insert into orderdetail(orderid,prod_id,quantity)values('{}','{}',1)".format(orderId,prodId)       
        db_conn.execute(consulta)

        totalAmount = db_conn.execute("select totalamount from orders where orderid='{}';".format(orderId)).fetchall()
        
        db_conn.close()
        return totalAmount[0][0]

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return None




def db_updateCart(peliId,orderId,quantity):

    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()

        # Cogemos el prod_id correspondiente a la peli que hemos metido
        consultaGetProd = "Select prod_id from products where movieid='{}'".format(peliId)
        db_resultProdId = db_conn.execute(consultaGetProd).fetchall()
        prodId = db_resultProdId[0][0]
        
        # actualizamos el orderdetail modificando la cantidad
        consulta = "update orderdetail set quantity='{}' where orderid='{}' and prod_id='{}';".format(quantity,orderId,prodId)       
        db_conn.execute(consulta)
        totalAmount = db_conn.execute("select totalamount from orders where orderid='{}';".format(orderId)).fetchall()
        db_conn.close()
        return totalAmount[0][0]

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return None

def db_compra(orderId, username,userId, saldo):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
        
        # actualizamos el orderdetail poniendo el estado a paid
        consulta = "update orders set status='Paid' where orderid='{}';".format(orderId)       
        db_conn.execute(consulta)
        # actualizamos el saldo del usuario
        db_actualizasaldo(username, saldo)
        newid = db_newCart(userId)
        db_conn.close()
        return newid

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return 'Something is broken'

def db_eliminarPelicula(orderId, id):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
        
        prodid = "Select prod_id from products where movieid = '{}'".format(id)
        prodid = db_conn.execute(prodid).fetchone()[0]

        #quantity = "Select quantity from orderdetail where prod_id = '{}' and orderid ='{}'".format(prodid,orderId)
        #q = db_conn.execute(quantity).fetchone()[0]

        delete = "delete from orderdetail where prod_id = '{}' and orderid ='{}'".format(prodid,orderId)
        db_conn.execute(delete)

        #query = "Select price from products where prod_id={}".format(prodid)
        #price = db_conn.execute(query).fetchone()[0]
#
        #total = "Select totalamount from orders where orderid = {}".format(orderId)
        #total = db_conn.execute(total).fetchone()[0]
        #total -= price*q
#
        #update = "Update orders set totalamount = '{}' where orderid = '{}'".format(total, orderId)
        #db_conn.execute(update)        

        db_conn.close()

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return 'Something is broken'

#añadir pelicula --> si no ha hecho login es igual que antes, si ha hecho login añadimos pelicula: miramos que haya un order a ese estado a null(si hay carrito ya creado) metemos la peli, creando un order detail. Miramos si la pelicula esta en el carrito subimos solo 1 en el cuantity. 
#Para el orderid null saca

def db_getCart(orderId):
    try:
        # conexion a la base de datos
        db_conn = None
        db_conn = db_engine.connect()
        consulta = "select imdb_movies.movieid, movietitle, year, directorname,quantity\
                    from imdb_movies,imdb_directors,imdb_directormovies,products,orderdetail\
                    where imdb_movies.movieid = imdb_directormovies.movieid and\
                    imdb_directors.directorid = imdb_directormovies.directorid and\
                    imdb_movies.movieid = products.movieid and products.prod_id = orderdetail.prod_id and\
                    orderdetail.orderid = '{}';".format(orderId)
                    
        db_result = db_conn.execute(consulta).fetchall()
       
        peliculas = []
        peli = {}
        actor = {}
       
        for row in db_result:
            peli = {}
            peli['id'] = row[0]
            peli['titulo'] = row[1]
            peli['poster'] ="../static/imagenes/"+ str(row[0])+".jpg"
            peli['director'] = row[3]
            peli['año'] = str(row[2])
            peli['categoria'] = []
            peli['actores'] = []
            peli['cantidad'] = row[4]
            peli['stock'] = []
            listaStock = db_stock(row[0])
            if listaStock:
                st = int(listaStock[0][0])
            else:
                st = 10
            # En caso de que haya poco stock solo se llega hasta el max
            # si el stock es alto solo dejamos coger 15 peliculas como max
            if st < 10:
                r = st
            else:
                r = 15
            for i in range(1,r):
                aux = {}
                aux['st'] = i
                peli['stock'].append(aux)
            #Hacer dict con precio tipo peli (description)
            consultaPri = "Select price from products where products.movieid ='{}' limit 1;".format(row[0])
            db_resultPri = db_conn.execute(consultaPri).fetchall()
            peli['precio'] = str(db_resultPri[0][0])

            consultaCat = "select movie_genres.genre from imdb_moviegenres, movie_genres\
                            where movie_genres.genre = imdb_moviegenres.genre and imdb_moviegenres.movieid = '{}'\
                            order by movie_genres.genre desc;".format(row[0])
            db_resultCat = db_conn.execute(consultaCat).fetchall()

            for r in db_resultCat:
                peli['categoria'].append(r[0])

            consultaAct = "select imdb_actors.actorid, imdb_actors.actorname, character, creditsposition\
                            from imdb_actors, imdb_actormovies\
                            where imdb_actors.actorid = imdb_actormovies.actorid and\
                            imdb_actormovies.movieid = '{}' order by creditsposition ASC limit 5;".format(row[0])
            db_resultAct = db_conn.execute(consultaAct).fetchall()

            for r in db_resultAct:
                actor = {}
                actor['nombre'] = r[1]
                actor['personaje'] = r[2]
                actor['foto'] = r[1]+".jpg"
                peli['actores'].append(actor)

            peliculas.append(peli)


        db_conn.close()

        return peliculas

    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return None

def getTotalAmount(orderId):
    try:
        db_conn = None
        db_conn = db_engine.connect()
        consulta = "select totalamount from orders where orderid = '{}';".format(orderId)
                    
        db_result = db_conn.execute(consulta).fetchall()
        db_conn.close()

        return list(db_result)
    except:
        if db_conn is not None:
            db_conn.close()
        print("Exception in DB access:")
        print("-"*60)
        traceback.print_exc(file=sys.stderr)
        print("-"*60)

        return None


def dbConnect():
    return db_engine2.connect()

def dbCloseConnect(db_conn):
    db_conn.close()
def getListaCliMes(db_conn, mes, anio, iumbral, iintervalo, use_prepare, break0, niter):

    # TODO: implementar la consulta; asignar nombre 'cc' al contador resultante
    consulta = " ... "
    
    # TODO: ejecutar la consulta 
    # - mediante PREPARE, EXECUTE, DEALLOCATE si use_prepare es True
    # - mediante db_conn.execute() si es False

    # Array con resultados de la consulta para cada umbral
    dbr=[]

    for ii in range(niter):

        # TODO: ...

        # Guardar resultado de la query
        dbr.append({"umbral":iumbral,"contador":res['cc']})

        # TODO: si break0 es True, salir si contador resultante es cero
        
        # Actualizacion de umbral
        iumbral = iumbral + iintervalo
                
    return dbr


def getMovies(anio):
    # conexion a la base de datos
    db_conn = db_engine2.connect()

    query="select movietitle from imdb_movies where year = '" + anio + "'"
    resultproxy=db_conn.execute(query)

    a = []
    for rowproxy in resultproxy:
        d={}
        # rowproxy.items() returns an array like [(key0, value0), (key1, value1)]
        for tup in rowproxy.items():
            # build up the dictionary
            d[tup[0]] = tup[1]
        a.append(d)
        
    resultproxy.close()  
    
    db_conn.close()  
    
    return a
    
    
def getCustomer(username, password):
    # conexion a la base de datos
    db_conn = db_engine2.connect()

    query="select * from customers where username='" + username + "' and password='" + password + "'"
    res=db_conn.execute(query).first()
    
    db_conn.close()  

    if res is None:
        return None
    else:
        return {'firstname': res['firstname'], 'lastname': res['lastname']}
    
def delCustomer(customerid, bFallo, bSQL, duerme, bCommit):
    
    # Array de trazas a mostrar en la página
    dbr=[]

    db_conn = None
    db_conn = db_engine2.connect()

    # TODO: Ejecutar consultas de borrado
    # - ordenar consultas según se desee provocar un error (bFallo True) o no
    # - ejecutar commit intermedio si bCommit es True
    # - usar sentencias SQL ('BEGIN', 'COMMIT', ...) si bSQL es True
    # - suspender la ejecución 'duerme' segundos en el punto adecuado para forzar deadlock
    # - ir guardando trazas mediante dbr.append()

   
    try:
        if bSQL is True:
            db_conn.execute("BEGIN")
        else:
            transaccion = db_conn.begin()

        print("ELSE")
        borrar1 = "delete from orderdetail where orderid in (select orderid from orders where customerid = '{}')​​".format(customerid)
        print("ANTES")
        resultado=db_conn.execute("delete from orderdetail where orderid in (select orderid from orders where customerid = '{}')".format(customerid))
        print("DESPUES")
        print(resultado)
        traza = "Borramos el order​​ de orderdetail"
        dbr.append(traza)

        if bCommit is True:
            if bSQL is True:
                dbr.append('Realizamos Commit')
                db_conn.execute("COMMIT")
                dbr.append('Realizamos Begin')
                db_conn.execute("BEGIN")
            else:
                transaccion.commit()
                dbr.append(' Realizamos Commit')
                dbr.append('Realizamos Begin')
                transaccion = db_conn.begin()

        # Si tiene que haber fallo
        if bFallo is True:
            borrar2 = "delete from customers where customerid={}​​".format(customerid)
            traza = "Borramos el customer con id : {}​​".format(customerid)
            dbr.append(traza)
            db_conn.execute(borrar2)
        else:
            borrar3 = "delete from orders where customerid = '{}'".format(customerid)
            db_conn.execute(borrar3)
            traza = "Borramos los orders del customer {}".format(customerid)
            dbr.append(traza)
            

            # hacemos deadlock
            if duerme > 0: 
                traza = "Antes Deadlock de {}".format(duerme)
                dbr.append(traza)
                time.sleep(duerme)
                traza = "Tras Deadlock de {}".format(duerme)
            dbr.append(traza)
            borrar4 = "delete from customers where customerid = '{}'".format(customerid)
            db_conn.execute(borrar4)
            traza = "Borramos el customer con id : {}​​".format(customerid)
            dbr.append(traza)
            

            if bSQL is True:
                dbr.append('Realizamos Commit')
                db_conn.execute("COMMIT")
            else:
                transaccion.commit()
                dbr.append(' Realizamos Commit')

    except Exception as e:
        # TODO: deshacer en caso de error
        if bSQL is False:
            transaccion.rollback()
        else:
            db_conn.execute("Rollback;")
        dbr.append("Realizamos Rollback")
        print(e)
            
    return dbr

def customerExists(id):
    db_conn = db_engine2.connect()

    query="select * from customers where customerid='{}'".format(id)
    res=db_conn.execute(query).first()
    if res:
        return True
    else:
        return False
    db_conn.close()  

    if res is None:
        return None
    else:
        return {'firstname': res['firstname'], 'lastname': res['lastname']}