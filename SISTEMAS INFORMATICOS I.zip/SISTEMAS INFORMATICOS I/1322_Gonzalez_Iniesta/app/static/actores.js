
function mostrarActores(id){
    let mydiv = $('#'+id)
    console.log(mydiv.style);
    console.log(mydiv);
    if(mydiv.css("display") === "none")
        mydiv.css("display","inline");
    else
        mydiv.css("display","none");
}
