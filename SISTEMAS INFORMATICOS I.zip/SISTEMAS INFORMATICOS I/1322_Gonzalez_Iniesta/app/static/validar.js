var formRegistro = document.getElementById("Registro");

var numeros="0123456789";   
window.onload = registro; 

function registro(){
   document.getElementById("ConfirmarRegistro").addEventListener('click', validarRegistro,false);
}
function validarPassword(){
  let p = $("#passwordRegistro"); 
  let user = $('#usernameRegistro'); 

   if (p.val() === user.val()){
      $('#ErrorRegistro').text("La contraseña no puede ser igual al nombre de usuario")

      error(p);
      return false;
   }
   return true;
 }


function validarUser(){
   let username = $("#usernameRegistro");

   if (username.val().length > 15){
      $('#ErrorRegistro').text("El nombre de usuario debe tener menos de 15 caracteres");
      error(username);
      return false;
   }
   return true;
 }


 function validarTarjeta(){
   tarjeta = $("#tarjetaReg");

   if (tarjeta.val().length < 10){
      $("#ErrorRegistro").text("la tarjeta debe contener 10 cifras");
      error(tarjeta);
      return false;
   }
   return true;
 }

 function validarRegistro (e){

   if(validarPassword() && validarUser() && validarTarjeta()){
      return true;
   }else{
      e.preventDefault();
      return false;
   }
 }

 function error(item){
   item.focus();
 }


 function fortaleza(){ 
   let contra = $('#passwordRegistro').val();
  console.log(contra);
   mensaje = "";
   if (contra === contra.toUpperCase() || contra === contra.toLowerCase()){
  
         mensaje = "Seguridad Baja, mezcla mayúsculas y minúsculas";
   }else if(contra.length > 10){
      mensaje = "Seguridad alta.";
   }else{
      mensaje = "Seguridad Media, añade más caracteres";
   }
   $('#ErrorPassword').text(mensaje);
   
 }
