
function Conectados(){
    $.ajax({
        url: '/usuariosConectados',
        type: 'GET',
        success: function(result){
            console.log(result);
            $('#usuariosConectados').text(result) ;
        }
    });
}

window.setInterval(Conectados, 3000);
