create or replace function getTopVentas(integer, integer)
returns table (anio int, movie VARCHAR, ventas integer)
as $$
DECLARE
  fecha1 integer = $1;
  fecha2 integer = $2;
  i record;
BEGIN


  LOOP
  exit when fecha1 > fecha2;
  FOR i in(
	      select s1.ye as y,imdb_movies.movietitle as movie1,s1.v as ventas1  from(
		Select movieid,MAX(peli1) as v,res.ye from (
			Select SUM(quantity) as peli1, products.movieid, cast(date_part('year',orders.orderdate) AS int)as ye from products, orderdetail,orders
			where products.prod_id = orderdetail.prod_id and
			orderdetail.orderid= orders.orderid and orders.orderid in (
				Select orderid from orders
				where cast(date_part('year',orders.orderdate) AS int) = fecha1
			) group By products.movieid,ye
		) as res group by movieid,res.ye) as s1,imdb_movies
	     where imdb_movies.movieid = s1.movieid  order by ventas1 desc limit 1
	  )LOOP

	anio:= i.y;
	movie := i.movie1;
	ventas:= i.ventas1;
	RETURN NEXT;
	END LOOP;     
       fecha1 = fecha1+1;
      END LOOP;
  
 end;
 $$ LANGUAGE 'plpgsql';


