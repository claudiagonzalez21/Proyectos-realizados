explain select count(*)
from orders
where status is null;

explain select count(*)
from orders
where status ='Shipped';

create index indice
ON orders (status);

EXPLAIN
select count(*)
from orders
where status is null;

EXPLAIN
select count(*)
from orders
where status ='Shipped';

DROP INDEX indice;

ANALYZE orders;

EXPLAIN
select count(*)
from orders
where status is null;

EXPLAIN
select count(*)
from orders
where status ='Shipped';

CREATE INDEX indice
ON orders (status);

EXPLAIN
select count(*)
from orders
where status is null;


EXPLAIN
select count(*)
from orders
where status ='Shipped';

EXPLAIN
select count(*)
from orders
where status ='Paid';

EXPLAIN
select count(*)
from orders
where status ='Processed';

