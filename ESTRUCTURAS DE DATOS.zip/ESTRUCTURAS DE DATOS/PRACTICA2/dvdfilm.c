#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sql.h>
#include <sqlext.h>
#include "odbc.h"

/*
 * example 1 with a fixed query, results retrieved with SQLGetData
 */

int main(int argc, char **argv) {
    SQLHENV env;
    SQLHDBC dbc;
    SQLHSTMT stmt;
    SQLRETURN ret; /* ODBC API return status */
    char query[5000];
    SQLLEN rows;

    if(argc != 2){
      printf("<film id>\n");
      return EXIT_FAILURE;
    }
    /* CONNECT */
    ret = odbc_connect(&env, &dbc);
    if (!SQL_SUCCEEDED(ret)) {
        return EXIT_FAILURE;
    }

    /* Allocate a statement handle */
    SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);

/******************************************************************/
/********************COMPROBACIÓN ARGUMENTOS***********************/
/******************************************************************/
    sprintf(query,"select film_id from film where film_id = %s",argv[1]);

    ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

    if(ret<0){
      odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
    }
    /* How many columns are there */
    SQLRowCount(stmt, &rows);

    if(rows<1){
      printf("El film_id introducido no existe \n");

          ret = odbc_disconnect(env, dbc);
          if (!SQL_SUCCEEDED(ret)) {
              return EXIT_FAILURE;
          }

      return EXIT_FAILURE;
    }

    SQLCloseCursor(stmt);

/*ELIMINAR CLAVES FORÁNEAS*/
    sprintf(query,"delete from film_actor where film_actor.film_id = '%s'",argv[1]);
    /* simple query */
    printf("%s\n",query);

    ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

    if(ret<0){
      odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
    }


    SQLCloseCursor(stmt);


    sprintf(query,"delete from film_category where film_category.film_id = '%s'",argv[1]);
    /* simple query */
    printf("%s\n",query);

    ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

    if(ret<0){
      odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
    }

    SQLCloseCursor(stmt);
    sprintf(query,"DELETE FROM payment \
        WHERE rental_id IN ( SELECT rental_id \
		                        FROM rental,inventory \
		                        WHERE rental.inventory_id = inventory.inventory_id AND inventory.film_id ='%s')",argv[1]);
    /* simple query */
    printf("%s\n",query);

    ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

    if(ret<0){
      odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
    }
    SQLCloseCursor(stmt);
    sprintf(query,"DELETE FROM rental\
                  where  rental.inventory_id IN ( SELECT inventory_id\
		                                               FROM inventory\
		                                                WHERE inventory.film_id ='%s')",argv[1]);
    /* simple query */
    printf("%s\n",query);

    ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

    if(ret<0){
      odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
    }

    SQLCloseCursor(stmt);

    sprintf(query,"DELETE FROM inventory where inventory.film_id ='%s'",argv[1]);
    /* simple query */
    printf("%s\n",query);

    ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

    if(ret<0){
      odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
    }
    SQLCloseCursor(stmt);
/************ELIMINAR CLAVE PRIMARIA***************/

    sprintf(query,"DELETE FROM film where film.film_id =  '%s'",argv[1]);
    /* simple query */
    printf("%s\n",query);

    ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

    if(ret<0){
      odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
    }
    SQLCloseCursor(stmt);
/*********COMPROBACIÓN***********/
    sprintf(query,"SELECT * FROM film where film_id = '%s'",argv[1]);
    /* simple query */
    printf("%s\n",query);

    ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

    if(ret<0){
      odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
    }

    /* How many columns are there */
    SQLRowCount(stmt, &rows);

    if(rows<1){
      printf("Se ha eliminado correctamente \n");
    }
    SQLCloseCursor(stmt);
    /* DISCONNECT */
    SQLFreeHandle(SQL_HANDLE_STMT,stmt);
    ret = odbc_disconnect(env, dbc);
    if (!SQL_SUCCEEDED(ret)) {
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
