#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sql.h>
#include <sqlext.h>
#include "odbc.h"

/*
 * example 1 with a fixed query, results retrieved with SQLGetData
 */
int customer(int argc,char** argv);
int film(int argc,char** argv);
int rent(int argc,char** argv);
int recommend(int argc,char** argv);
int main(int argc, char **argv) {

  if(argc < 2){
    printf("<dvdreq> <customer/film/rent/recommend>\n");
    return EXIT_FAILURE;
  }
if(strcmp(argv[1],"customer") == 0 ){
  customer(argc,argv);
}else if(strcmp(argv[1],"film") == 0){
  film(argc,argv);
} else if(strcmp(argv[1],"rent") == 0){
  rent(argc,argv);
} else{
  recommend(argc,argv);
}

  return 0;
}
/*************************************************/
/*************************************************/
/*************************************************/
/*****************DVDREQ CUSTOMER********************/
/************************************************/
/************************************************/
int customer(int argc, char** argv){
  SQLHENV env;
  SQLHDBC dbc;
  SQLHSTMT stmt;
  SQLRETURN ret; /* ODBC API return status */
  SQLCHAR first_name[512];
  SQLCHAR last_name[512];
  SQLCHAR address[512];
  SQLCHAR address2[512];
  SQLCHAR district[512];
  char query[5000];
  SQLLEN rows;
  SQLINTEGER customer_id;
  SQLINTEGER address_id;
  SQLINTEGER city_id;
  SQLINTEGER postal_code;
  SQL_DATE_STRUCT create_date;


  if(argc < 4){
    printf("<nombre> <apellido>\n");
    return EXIT_FAILURE;
  }



  /* CONNECT */
  ret = odbc_connect(&env, &dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  /* Allocate a statement handle */
  SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);

  sprintf(query,"select customer_id, first_name, last_name, create_date,\
                        customer.address_id, address.address_id, address, address2,\
                        district, city_id, postal_code \
                 from customer, address \
                 where (first_name  = '%s' OR last_name = '%s' )AND address.address_id=customer.address_id",argv[2],argv[3]);
  /* simple query */
  printf("%s\n",query);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }
  /* How many columns are there */
  SQLRowCount(stmt, &rows);

  printf("\n");

  /* Loop through the rows in the result-set */
  while (SQL_SUCCEEDED(ret = SQLFetch(stmt))) {
      ret = SQLGetData(stmt, 1, SQL_C_SLONG, &customer_id, sizeof(SQLINTEGER), NULL);
      ret = SQLGetData(stmt, 2, SQL_C_CHAR, first_name, sizeof(first_name), NULL);
      ret = SQLGetData(stmt, 3, SQL_C_CHAR, last_name, sizeof(last_name), NULL);
      ret = SQLGetData(stmt, 4, SQL_C_TYPE_DATE, &create_date, sizeof(SQL_DATE_STRUCT), NULL);
      ret = SQLGetData(stmt, 5, SQL_C_SLONG, &address_id, sizeof(SQLINTEGER), NULL);
      ret = SQLGetData(stmt, 6, SQL_C_CHAR, address, sizeof(address), NULL);
      ret = SQLGetData(stmt, 7, SQL_C_CHAR, address2, sizeof(address2), NULL);
      ret = SQLGetData(stmt, 8, SQL_C_CHAR, district, sizeof(district), NULL);
      ret = SQLGetData(stmt, 9, SQL_C_SLONG, &city_id, sizeof(SQLINTEGER), NULL);
      ret = SQLGetData(stmt, 10, SQL_C_SLONG, &postal_code, sizeof(SQLINTEGER), NULL);


      printf("%d\t%s\t%s\t%d-%d-%d\t%d\t%s\t%s\t%s\t%d\t%d\n", customer_id, first_name, last_name, create_date.day, create_date.month, create_date.year, address_id, address, address2, district, city_id, postal_code);
  }

  /* DISCONNECT */
  SQLFreeHandle(SQL_HANDLE_STMT,stmt);
  ret = odbc_disconnect(env, dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}
/*************************************************/
/*************************************************/
/*************************************************/
/*****************DVDREQ FILM********************/
/************************************************/
/************************************************/
int film(int argc,char** argv){
  SQLHENV env;
  SQLHDBC dbc;
  SQLHSTMT stmt;
  SQLRETURN ret; /* ODBC API return status */
  SQLCHAR title[1000];
  SQLCHAR name[512];
  SQLCHAR description[512];
  SQLCHAR first_name[512];
  SQLCHAR last_name[512];
  char query[5000];
  SQLLEN rows;
  SQLINTEGER film_id;
  SQLINTEGER length;
  SQLINTEGER release_year;


  if(argc != 3){
    printf("<titulo>\n");
    return EXIT_FAILURE;
  }

  /* CONNECT */
  ret = odbc_connect(&env, &dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  /* Allocate a statement handle */
  SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);




  sprintf(query,"select title, film.film_id, release_year, \
                        film.length, language.name, description, first_name, last_name \
                 from film, actor, film_actor, language \
                 where title LIKE '%%%s%%' AND language.language_id=film.language_id \
                                       AND film.film_id=film_actor.film_id \
                                       AND film_actor.actor_id=actor.actor_id",argv[2]);
  /* simple query */
  printf("%s\n",query);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }
  /* How many columns are there */
  SQLRowCount(stmt, &rows);

  printf("\n");

  /* Loop through the rows in the result-set */
  while (SQL_SUCCEEDED(ret = SQLFetch(stmt))) {
      ret = SQLGetData(stmt, 1, SQL_C_CHAR, title, sizeof(title), NULL);
      ret = SQLGetData(stmt, 2, SQL_C_SLONG, &film_id, sizeof(SQLINTEGER), NULL);
      ret = SQLGetData(stmt, 3, SQL_C_SLONG, &release_year, sizeof(SQLINTEGER), NULL);
      ret = SQLGetData(stmt, 4, SQL_C_SLONG, &length, sizeof(SQLINTEGER), NULL);
      ret = SQLGetData(stmt, 5, SQL_C_CHAR, name, sizeof(name), NULL);
      ret = SQLGetData(stmt, 6, SQL_C_CHAR, description, sizeof(description), NULL);
      ret = SQLGetData(stmt, 7, SQL_C_CHAR, first_name, sizeof(first_name), NULL);
      ret = SQLGetData(stmt, 8, SQL_C_CHAR, last_name, sizeof(last_name), NULL);



      printf("%s\t%d\t%d\t%d\t%s\t%s\t%s\t%s\n", title, film_id, release_year, length, name, description, first_name, last_name);
  }

  /* DISCONNECT */
  SQLFreeHandle(SQL_HANDLE_STMT,stmt);
  ret = odbc_disconnect(env, dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}
/*************************************************/
/*************************************************/
/*************************************************/
/*****************DVDREQ RENT********************/
/************************************************/
/************************************************/
int rent(int argc,char** argv){
  SQLHENV env;
  SQLHDBC dbc;
  SQLHSTMT stmt;
  SQLRETURN ret; /* ODBC API return status */
  char query[5000];
  SQLLEN rows;
  SQLINTEGER rental_id;
  SQLCHAR rental_date[512];
  SQLINTEGER film_id;
  SQLCHAR title[1000];
  SQLINTEGER staff_id;
  SQLCHAR first_name[512];
  SQLINTEGER store_id;
  double amount;

  if(argc != 5){
    printf("<customer_id> <Fecha1:anio-mes-dia> <Fecha2:anio-mes-dia>\n");
    return EXIT_FAILURE;
  }


  /* CONNECT */
  ret = odbc_connect(&env, &dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  /* Allocate a statement handle */
  SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);



  sprintf(query,"select rental.rental_id, rental.rental_date, film.film_id, title, rental.staff_id, staff.first_name, staff.store_id, amount \
                 from rental, film, staff, payment, store,inventory,customer \
                 where rental.rental_date BETWEEN '%s' AND '%s' \
                       AND customer.customer_id = '%s' \
                       AND inventory.film_id = film.film_id \
                       AND rental.inventory_id = inventory.inventory_id \
                       AND rental.customer_id = customer.customer_id \
                       AND rental.staff_id=staff.staff_id \
                       AND staff.store_id=store.store_id \
                       AND payment.rental_id=rental.rental_id \
                       ORDER BY rental.rental_date",argv[3], argv[4], argv[2]);
  /* simple query */
  printf("%s\n",query);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }
  /* How many columns are there */
  SQLRowCount(stmt, &rows);

  printf("\n");

  /* Loop through the rows in the result-set */
  while (SQL_SUCCEEDED(ret = SQLFetch(stmt))) {
      ret = SQLGetData(stmt, 1, SQL_C_SLONG, &rental_id, sizeof(SQLINTEGER), NULL);
      ret = SQLGetData(stmt, 2, SQL_C_CHAR, rental_date, sizeof(rental_date), NULL);
      ret = SQLGetData(stmt, 3, SQL_C_SLONG, &film_id, sizeof(SQLINTEGER), NULL);
      ret = SQLGetData(stmt, 4, SQL_C_CHAR, title, sizeof(title), NULL);
      ret = SQLGetData(stmt, 5, SQL_C_SLONG, &staff_id, sizeof(SQLINTEGER), NULL);
      ret = SQLGetData(stmt, 6, SQL_C_CHAR, first_name, sizeof(first_name), NULL);
      ret = SQLGetData(stmt, 7, SQL_C_SLONG, &store_id, sizeof(SQLINTEGER), NULL);
      ret = SQLGetData(stmt, 8, SQL_C_DOUBLE, &amount, sizeof(double), NULL);



      printf("%d\t%s\t%d\t%s\t%d\t%s\t%d\t%f\n", rental_id, rental_date, film_id, title, staff_id, first_name, store_id, amount);
  }

  /* DISCONNECT */
  SQLFreeHandle(SQL_HANDLE_STMT,stmt);
  ret = odbc_disconnect(env, dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}
/*************************************************/
/*************************************************/
/*************************************************/
/*****************DVDREQ RECOMMEND********************/
/************************************************/
/************************************************/
int recommend(int argc,char** argv){
  SQLHENV env;
  SQLHDBC dbc;
  SQLHSTMT stmt;
  SQLRETURN ret; /* ODBC API return status */
  char query[5000];
  SQLLEN rows;
  SQLCHAR title1[1000];
  SQLCHAR title2[1000];
  SQLCHAR title3[1000];


  if(argc != 3){
    printf("<customer_id>\n");
    return EXIT_FAILURE;
  }


  /* CONNECT */
  ret = odbc_connect(&env, &dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  /* Allocate a statement handle */
  SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);


  sprintf(query,"Select film.title \
                from film, customer, rental, inventory, category, film_category \
                where customer.customer_id = rental.customer_id \
                    AND inventory.inventory_id = rental.inventory_id \
                    AND inventory.film_id = film.film_id \
                    AND category.category_id = film_category.category_id \
                    AND category.category_id IN (	Select category.category_id \
                            From film, customer, rental, inventory, category, film_category \
                            where customer.customer_id = %s \
                              AND customer.customer_id = rental.customer_id \
                              AND inventory.inventory_id = rental.inventory_id \
                              AND inventory.film_id = film.film_id \
                              AND category.category_id = film_category.category_id \
                              AND film.film_id = film_category.film_id \
                            Group by category.category_id \
                            Order by count(*) Desc limit 1) \
                    AND film.film_id NOT IN (Select film.film_id \
                            From film, customer, rental, inventory \
                            where customer.customer_id = 1 \
                              AND customer.customer_id = rental.customer_id \
                              AND inventory.inventory_id = rental.inventory_id \
                              AND inventory.film_id = film.film_id ) \
                Group by film.film_id \
                Order by count (*) desc limit 3",argv[2]);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }
  /* How many columns are there */
  SQLRowCount(stmt, &rows);

  printf("\n");

  /* Loop through the rows in the result-set */
  while (SQL_SUCCEEDED(ret = SQLFetch(stmt))) {
      ret = SQLGetData(stmt, 1, SQL_C_CHAR, title1, sizeof(title1), NULL);
      ret = SQLGetData(stmt, 2, SQL_C_CHAR, title2, sizeof(title2), NULL);
      ret = SQLGetData(stmt, 3,SQL_C_CHAR, title3, sizeof(title3), NULL);

      printf("%s\n%s\n%s\n", title1, title2, title3);
  }

  /* DISCONNECT */
  SQLFreeHandle(SQL_HANDLE_STMT,stmt);

  ret = odbc_disconnect(env, dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}
