#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sql.h>
#include <sqlext.h>
#include "odbc.h"

/*
 * example 1 with a fixed query, results retrieved with SQLGetData
 */
int new(int argc,char** argv);
int rem(int argc,char** argv);

int main(int argc, char **argv) {

  if(argc < 2){
    printf("<dvdreq> <new/remove>\n");
    return EXIT_FAILURE;
  }
if(strcmp(argv[1],"new") == 0 ){
  new(argc,argv);

}else{
  rem(argc,argv);
}

  return 0;
}

/*************************************************/
/*************************************************/
/*************************************************/
/*****************DVDRENT NEW********************/
/************************************************/
/************************************************/

int new(int argc,char** argv){
  SQLHENV env;
  SQLHDBC dbc;
  SQLHSTMT stmt;
  SQLRETURN ret; /* ODBC API return status */
  char query[5000];
  SQLLEN rows;
  SQLINTEGER inventory_id;
  SQLINTEGER rental_id;

  if(argc != 8){
    printf("<customer Id> <film id> <staff id> <store id> <amount>\n");

    return EXIT_FAILURE;
  }

  /* CONNECT */
  ret = odbc_connect(&env, &dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  /* Allocate a statement handle */
  SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);

  /*************************************************************************/
  /*************************************************************************/
  /*************************************************************************/
  /****************INICIO DE COPMPROBACIONES DE ENTRADA  *******************/
  /*************************************************************************/
  /*************************************************************************/
  /*************************************************************************/


/*COMPROBACION DE CUSTOMER*/
  sprintf(query,"select customer_id from customer where customer_id = '%s'",argv[2]);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }
  /* How many columns are there */
  SQLRowCount(stmt, &rows);

  if(rows<1){
    printf("El cutomer_id introducido no existe \n");

        ret = odbc_disconnect(env, dbc);
        if (!SQL_SUCCEEDED(ret)) {
            return EXIT_FAILURE;
        }
  }
  SQLCloseCursor(stmt);

  /*COMPROBACION DE FILM*/
  sprintf(query,"select film_id from film where film_id = %s",argv[3]);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }
  /* How many columns are there */
  SQLRowCount(stmt, &rows);

  if(rows<1){
    printf("El film_id introducido no existe \n");

        ret = odbc_disconnect(env, dbc);
        if (!SQL_SUCCEEDED(ret)) {
            return EXIT_FAILURE;
        }
  }
  SQLCloseCursor(stmt);

  /*COMPROBACION DE STAFF_ID*/
  sprintf(query,"select staff_id from staff where staff_id = %s",argv[4]);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }
  /* How many columns are there */
  SQLRowCount(stmt, &rows);

  if(rows<1){
    printf("El staff_id introducido no existe \n");

        ret = odbc_disconnect(env, dbc);
        if (!SQL_SUCCEEDED(ret)) {
            return EXIT_FAILURE;
        }
  }

  SQLCloseCursor(stmt);

  /*COMPROBACION DE STORE_ID*/
  sprintf(query,"select store_id from store where store_id = %s",argv[5]);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }
  /* How many columns are there */
  SQLRowCount(stmt, &rows);

  if(rows<1){
    printf("El store_id introducido no existe \n");

        ret = odbc_disconnect(env, dbc);
        if (!SQL_SUCCEEDED(ret)) {
            return EXIT_FAILURE;
        }
  }
  SQLCloseCursor(stmt);

  /*COMPROBACION DE AMOUNT*/
if(*argv[6]<0){
  printf("El precio no es correcto\n");
      ret = odbc_disconnect(env, dbc);
      if (!SQL_SUCCEEDED(ret)) {
          return EXIT_FAILURE;
      }
}

/*************************************************************************/
/************************************************************************/
/*************************************************************************/
/*******************FIN DE COPMPROBACIONES DE ENTRADA  *******************/
/*************************************************************************/
/************************************************************************/
/*************************************************************************/




/*********OBTENCIÓN DE INVENTORY_ID***********/

sprintf(query,"Select inventory_id, store_id\
            from inventory\
            where film_id = '%s' AND store_id = '%s' AND\
            inventory_id not in (select inventory_id from rental where return_date is NULL)\
            limit 1",argv[3],argv[5]);
/* simple query */

SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);


if(SQL_SUCCEEDED(ret = SQLFetch(stmt))){
ret = SQLGetData(stmt, 1, SQL_C_SLONG, &inventory_id, sizeof(SQLINTEGER), NULL);
}



SQLCloseCursor(stmt);

sprintf(query,"Insert into rental (inventory_id, customer_id, staff_id, rental_date) values (%d, %s, %s,now()) returning rental_id",inventory_id,argv[2],argv[4]);



ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

if(ret<0){
  odbc_extract_error("1", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
}

if(SQL_SUCCEEDED(ret = SQLFetch(stmt))){
  ret = SQLGetData(stmt, 1, SQL_C_SLONG, &rental_id, sizeof(SQLINTEGER), NULL);
}


SQLCloseCursor(stmt);

sprintf(query,"Insert into payment (customer_id, staff_id, rental_id, amount,payment_date) values (%s, %s, %d, %s, now()) returning rental_id",argv[2],argv[4],rental_id, argv[5]);



  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("2", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }


  SQLCloseCursor(stmt);

  /**********COMPROBACIÓN************/

  sprintf(query,"SELECT rental_date FROM rental where rental_id = %d",rental_id);

    ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

    SQLRowCount(stmt, &rows);

    if(rows>=1){
      printf("CORRECTA INSERCIÓN DEL ALQUILER CON ID: %d \n",rental_id);

          ret = odbc_disconnect(env, dbc);
          if (!SQL_SUCCEEDED(ret)) {
              return EXIT_FAILURE;
          }
    }

    SQLCloseCursor(stmt);

 SQLFreeHandle(SQL_HANDLE_STMT,stmt);

  ret = odbc_disconnect(env, dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

/*************************************************/
/*************************************************/
/*************************************************/
/*****************DVDRENT NEW********************/
/************************************************/
/************************************************/
int rem(int argc,char** argv){
  SQLHENV env;
  SQLHDBC dbc;
  SQLHSTMT stmt;
  SQLRETURN ret; /* ODBC API return status */
  char query[5000];
  SQLLEN rows;

  if(argc != 3){
    printf("<rental Id> \n");

    return EXIT_FAILURE;
  }
  /* CONNECT */
  ret = odbc_connect(&env, &dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  /* Allocate a statement handle */
  SQLAllocHandle(SQL_HANDLE_STMT, dbc, &stmt);

  /******************************************************************/
  /********************COMPROBACIÓN ARGUMENTOS***********************/
  /******************************************************************/
  sprintf(query,"select rental_id from rental where rental_id = %s",argv[2]);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }
  /* How many columns are there */
  SQLRowCount(stmt, &rows);

  if(rows<1){
    printf("El rental_id introducido no existe \n");

        ret = odbc_disconnect(env, dbc);
        if (!SQL_SUCCEEDED(ret)) {
            return EXIT_FAILURE;
        }

    return EXIT_FAILURE;
  }

  SQLCloseCursor(stmt);

  /*ELIMINAR CLAVES FORÁNEAS*/
  sprintf(query,"DELETE FROM payment where rental_id = '%s'",argv[2]);
  /* simple query */
  printf("%s\n",query);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }


  SQLCloseCursor(stmt);


  /************ELIMINAR CLAVE PRIMARIA***************/

  sprintf(query,"DELETE FROM rental where rental_id ='%s'",argv[2]);
  /* simple query */
  printf("%s\n",query);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }
  SQLCloseCursor(stmt);
  /*********COMPROBACIÓN***********/
  sprintf(query,"SELECT * FROM rental where rental_id = '%s'",argv[2]);
  /* simple query */
  printf("%s\n",query);

  ret=SQLExecDirect(stmt, (SQLCHAR*) query, SQL_NTS);

  if(ret<0){
    odbc_extract_error("", stmt, SQL_HANDLE_STMT); /*REISAR LO DE ENTRE COMILLAS*/
  }

  /* How many columns are there */
  SQLRowCount(stmt, &rows);

  if(rows<1){
    printf("Se ha eliminado correctamente \n");
  }
  SQLCloseCursor(stmt);
  /* DISCONNECT */
  SQLFreeHandle(SQL_HANDLE_STMT,stmt);
  ret = odbc_disconnect(env, dbc);
  if (!SQL_SUCCEEDED(ret)) {
      return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;

}
