
  SELECT p1.*
  FROM
  (SELECT customer.customer_id, first_name, last_name, count(rental_id) as ventas
    FROM customer, rental
    WHERE customer.customer_id = rental.customer_id
    GROUP BY customer.customer_id ) as p1,

    (SELECT max(p2.ventas) as maximo
    FROM (SELECT customer_id, count(rental_id) as ventas
    FROM rental
    GROUP BY customer_id
      )as p2
    )as p3

    WHERE p1.ventas = p3.maximo
