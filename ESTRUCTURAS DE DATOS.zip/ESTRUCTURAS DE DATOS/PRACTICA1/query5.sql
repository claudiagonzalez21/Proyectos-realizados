
SELECT p1.name
FROM
 (SELECT inventory.film_id, language.name, language.language_id,film.language_id, rental.inventory_id, count(rental_id) as ventas
  FROM film, rental
  WHERE inventory.film_id = film.film_id
  AND inventory.inventory_id = rental.inventory_id 
  AND language.language_id = film.language_id
  GROUP BY language.name ) as p1,

  (SELECT max (p2.ventas) as maximo
    FROM (SELECT name, count(rental_id) as ventas
          FROM rental
          GROUP BY name
        ) as p2
    ) as p3
 WHERE p1.name = p3.maximo
