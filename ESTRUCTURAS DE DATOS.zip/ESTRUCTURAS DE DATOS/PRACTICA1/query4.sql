
  SELECT p1.name
  FROM
  (SELECT language.language_id, name, count(film_id) as films
    FROM language, film
    WHERE language.language_id = film.language_id
    GROUP BY language.language_id ) as p1,

    (SELECT max(p2.films) as maximo
    FROM (SELECT language_id, count(film_id) as films
    FROM film
    GROUP BY language_id
      )as p2
    )as p3

    WHERE p1.films = p3.maximo
