SELECT 
	  DISTINCT city.city_id, city.city
	  FROM city, address, customer, rental, inventory, film, film_actor, actor
	  WHERE city.city_id = address.city_id 

		AND address.address_id = customer.address_id
			AND customer.customer_id = rental.customer_id
				AND inventory.inventory_id = rental.inventory_id
					AND film.film_id = inventory.film_id
						AND film_actor.film_id = film.film_id
							AND actor.actor_id = film_actor.actor_id
								AND actor.first_name = 'Bob'
										AND actor.last_name = 'Fawcett'
										
	ORDER BY city.city ASC
	      
