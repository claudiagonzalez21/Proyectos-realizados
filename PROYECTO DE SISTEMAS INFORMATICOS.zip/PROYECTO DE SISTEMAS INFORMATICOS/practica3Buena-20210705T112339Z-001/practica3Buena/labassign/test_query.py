from django.test import TestCase
from django.test import Client
from datetime import datetime, timedelta
import django
from core.models import (Student, Pair,
                         OtherConstraints)
from core.management.commands.populate import Command
import os
django.setup()
os.environ.setdefault('DJANGO_SETTINGS_MODULE',
                      'labassign.settings')


class QueryTests(TestCase):
    """Test that populate  has been saved data properly
       require files XXXX.pkl stored in the same directory that manage.py"""
    def setUp(self):
        print("HOLA")
        self.client = Client()
        # load Command class from populate
        c = Command()
        # execute populate
        c.handle(model='all', studentinfo='19-edat_psi.csv',
                 studentinfolastyear='19-edat_2_psi.csv')

    def test_query(self):

        user_1000 = get_Student(1000)
        if user_1000 is None:
            user_1000 = Student.objects.create(id=1000)
        print(user_1000)
        user_1001 = get_Student(1001)
        if user_1001 is None:
            user_1001 = Student.objects.create(id=1001)
        print(user_1001)
        pair = Pair.objects.get_or_create(student1=user_1000,
                                          student2=user_1001)
        print(pair)
        for p in Pair.objects.get(student1=user_1000):
            print(p)
            p.validate = True

        sgsd = datetime.now() + timedelta(days=1)
        oc = OtherConstraints.objects.get_or_create(selectGroupStartDate=sgsd)
        print(oc)
        i = 0
        for oc in OtherConstraints.objects:
            if i == 0:
                if(oc.selectGroupStartDate < datetime.now()):
                    print("Está en el pasado")
                else:
                    print("Está en el futuro")


def get_Student(id):
    print("HOLA")
    try:
        s = Student.objects.get(id=id)
    except Student.DoesNotExist:
        s = None
    return s
