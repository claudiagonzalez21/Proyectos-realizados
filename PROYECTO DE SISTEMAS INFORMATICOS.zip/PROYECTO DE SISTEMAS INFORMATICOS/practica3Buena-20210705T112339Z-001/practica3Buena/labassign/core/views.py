# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render
from django.shortcuts import redirect
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.utils import timezone

from core.models import (OtherConstraints, Pair, Student,
                         GroupConstraints, TheoryGroup,
                         LabGroup, Teacher)

def student_login(request):
    if request.user.is_authenticated:
        user = Student.objects.get(user=request.user)
        context_dict={}
        context_dict['error'] = ""
        context_dict['first_name'] = user.first_name
        context_dict['last_name'] = user.last_name
        return render(request, 'core/student_login.html',context=context_dict)

    elif request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        context_dict={}
        context_dict['error'] = ""
        if user:
            print(str(user.is_active))
            if user.is_active:
                login(request,user)
                return redirect(reverse('core:home'))
            else:
                #devolver el login pero con ese mensaje de error
                context_dict['error'] = "You can't login with that account."
                return redirect(request, 'core/student_login.html',context=context_dict)
        else:
            print("Invalid login details: {0}, {1}".format(username, password))
            context_dict['error'] = "You entered an invalid username or password."
            return render(request, 'core/student_login.html',context=context_dict)
    else:
        context_dict={}
        context_dict['error'] = ""
        return render(request, 'core/student_login.html',context=context_dict)

#Creo que hay que poner lo del loginrequired
@login_required
def convalidation(request):
#Un usuario dado s´olo puede solicitar la convalidaci´on de sus notas no las de
#otros alumnos. Implementad este requisito usando el sistema de verificaci´on de
#Django.
    if request.user.is_authenticated:
        conv = True
        user = Student.objects.get(user=request.user)
        gradeTheory = user.gradeTheoryLastYear
        gradeLab = user.gradeLabLastYear
        context_dict={}
        context_dict['theoryGrade'] = gradeTheory
        context_dict['labGrade'] = gradeLab
        context_dict['msg'] = "do not satify the requeriments for convalidation"
        pair = Pair.objects.filter(student1=user)
        #COMPROBAR QUE NO ESTÉ EN PAREJA VALIDATED O SE S1 EN SOLICITUD DE PAREJA
        if pair:
            conv = False
        else:
            pair = Pair.objects.filter(student2=user)
            if pair:

                if pair[0].validated is True:
                    conv = False
        if conv is True:

            oc = OtherConstraints.objects.filter().first()
            print(str(oc.minGradeLabConv))
            if oc.minGradeLabConv <= gradeLab and oc.minGradeTheoryConv <= gradeTheory:
                user.convalidationGranted = True
                user.save()
                context_dict['msg'] = "satify the requeriments for convalidation"
                    
        return render(request,'core/convalidation.html',context=context_dict)
                    
    else:
        return redirect(reverse('core:home'))

@login_required
def student_logout(request):
    logout(request)
    return render(request,'core/student_logout.html')


#FALTA METER EN EL DICT SI SOLICITA UN GRUPO DE PRACTICAS
def home(request):

    if request.user.is_authenticated:
        user = Student.objects.get(user=request.user)
        if not user:
            return render(request,'core/home.html')

        context_dict={}
        context_dict['username'] = user.first_name
        context_dict['lastname'] = user.last_name
        context_dict['lg'] = None
        if user.labGroup:
            context_dict['lg'] = True
            context_dict['labGroup'] = str(user.labGroup)
        context_dict['theoryGroup'] = str(user.theoryGroup)
        context_dict['pair'] = None
        context_dict['validated'] = None
        if user.convalidationGranted is True:
            context_dict['convalidationGranted'] =True
        else:
            context_dict['convalidationGranted'] =None

        p = Pair.objects.filter(student1=user)
        
        if p:
            pair = p[0]
        else:
            pair = None
         #REVISARLO!!!!!!!!!
        #Si hacemos filter con un student que si tiene pareja falla si hacemos con uno q no va
        #Si usamos get con un st que no tiene pareja falla si la tiene si va
        if pair:
            context_dict['pair'] = True
            s2 = pair.student2
            context_dict['pairmate'] = str(s2.first_name) + str(s2.last_name)
            if pair.validated is True:
                context_dict['validated'] = True
            else:
                context_dict['student2'] = str(s2)
        else:
            p = Pair.objects.filter(student2=user)
            if p:
                pair = p[0]
            else:
                pair = None
            if pair:
                context_dict['pair'] =True
                s1 = pair.student1
                context_dict['pairmate'] = str(s1.first_name) + str(s1.last_name)
                if pair.validated is True:
                    context_dict['validated'] = True
                else:
                    context_dict['student2'] = str(user)+" Has to validate the pair"
            else:
                context_dict['p'] ="NOT "

        return render(request,'core/home.html',context=context_dict)
    else:
        return render(request,'core/home.html')

@login_required
def applypair(request):
    if request.user.is_authenticated:
        context_dict={}
        user1 = Student.objects.get(user=request.user)
        print("YO"+str(user1))
        solicitud = True
        if request.method == 'POST':
            pair = Pair.objects.filter(student1=user1)
            pair2 = Pair.objects.filter(student2=user1)
            if pair:
                p = pair[0]
                if p.validated is True:
                    solicitud = False
                    context_dict['err']="User has already selected a pair"
            if pair2:
                p = pair2[0]
                if p.validated is True:
                    solicitud = False
                    context_dict['err']="User has already selected a pair"
            if solicitud is True:
                id2 = request.POST['secondMemberGroup']
                user2 = Student.objects.get(id=id2)
                pair = Pair.objects.filter(student1=user2, student2=user1)
                if pair:
                    pair[0].validated=True
                    pair[0].save()
                else:
                    pair = Pair.objects.get_or_create(student1=user1,student2=user2,validated=False)[0]
                    pair.save()
        context_dict['first_name'] = user1.first_name
        context_dict['last_name'] = user1.last_name
        context_dict['students'] = []
        lista = []
        st = []
        st = Student.objects.all()

        for s in st :
            if s is not user1:
                p = Pair.objects.filter(student1=s)
                if not p :
                    p = Pair.objects.filter(student2=s)
                    if not p:
                        lista.append(s)
                    else:
                        pair = p[0]
                        if pair.validated is False:
                            lista.append(s)
                else:
                    pair = p[0]
                    if pair.validated is False:
                        lista.append(s)

        context_dict['students'] = lista
        return render(request,'core/applypair.html',context=context_dict)

@login_required
def applygroup(request):
    if request.user.is_authenticated:
        context_dict={}
        user1 = Student.objects.get(user=request.user)
        tg = user1.theoryGroup
        gc = GroupConstraints.objects.filter(theoryGroup=tg)
        labgroups = LabGroup.objects.filter()
        context_dict['labGroups'] = []
        labGroupsAvailable = []
        #Guardamos los grupos que van a aparecer en el desplegable
        for labg in labgroups:
            if labg.counter < labg.maxNumberStudents:
                labGroupsAvailable.append(labg)

        context_dict['labGroups'] = labGroupsAvailable
        oc = OtherConstraints.objects.filter()[0]
        #En caso de que se pulse submit
        fechaActual = timezone.now()
        if request.method == 'POST':
            if oc.selectGroupStartDate > fechaActual:
                context_dict['error'] = "You can't choose a labGorup until "+str('{}-{}-{}'.format(oc.selectGroupStartDate.day, oc.selectGroupStartDate.month, oc.selectGroupStartDate.year))
                return render(request,'core/applygroup.html',context=context_dict)
            lgid = request.POST['labGroup']
            actualLg = user1.labGroup
            lg = LabGroup.objects.get(id=lgid)
            gc = GroupConstraints.objects.filter(theoryGroup=tg,labGroup=lg)
            if gc:
                #ANIADIR EL GRUPO AL STUDENT
                if lg.counter < lg.maxNumberStudents:
                    lg.counter += 1
                    user1.labGroup = lg
                    user1.save()
                    lg.save()
                #En caso de que ya estuviese en un grupo de practicas se le quita
                    if actualLg:
                        actualLg.counter -= 1
                        actualLg.save()
                #si user1 es parte de una pareja con estado validated se añade al pairmate
                pair1 = Pair.objects.filter(student1=user1)
                if pair1:
                    p = pair1[0]
                    if p.validated is True:
                        user2 = p.student2
                        lg.counter += 1
                        user2.labGroup = lg
                        user2.save()
                        lg.save()
                        #Si ya formaban parte de un grupo se le quita
                        if actualLg:
                            actualLg.counter -= 1
                            actualLg.save()
                pair2 = Pair.objects.filter(student2=user1)
                if pair2:
                    p = pair2[0]
                    if p.validated is True:
                        user2 = p.student1
                        lg.counter += 1
                        user2.labGroup = lg
                        user2.save()
                        lg.save()
                        #Si ya formaba parte de un grupo se le quita
                        if actualLg:
                            actualLg.counter -= 1
                            actualLg.save()
            else:
                context_dict['error'] = "You can't choose that labgroup because you are not part of the theoryGroup"
                

    return render(request,'core/applygroup.html',context=context_dict)
#Help viewseps
def login_help(request):
    return render(request,'core/login_help.html')


def convalidation_help(request):
    return render(request,'core/convalidation_help.html')

def partner_help(request):
    return render(request,'core/partner_help.html')

def group_help(request):
    gc = OtherConstraints.objects.filter()
    context_dict={}
    if gc.count()>0:
        g=gc[0]
       
        context_dict['startdate'] = g.selectGroupStartDate
    context_dict['currentdate'] = timezone.now
    
    return render(request,'core/group_help.html',context=context_dict)
