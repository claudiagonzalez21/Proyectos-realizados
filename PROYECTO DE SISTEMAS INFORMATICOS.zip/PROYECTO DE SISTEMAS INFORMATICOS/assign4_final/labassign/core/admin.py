from django.contrib import admin
from core.models import (Teacher, LabGroup, TheoryGroup,
                         GroupConstraints, Student, Pair,
                         OtherConstraints)
# Register your models here.

admin.site.register(Student)
admin.site.register(Teacher)
admin.site.register(LabGroup)
admin.site.register(GroupConstraints)
admin.site.register(OtherConstraints)
admin.site.register(TheoryGroup)
admin.site.register(Pair)
