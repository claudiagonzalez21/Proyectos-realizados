# Create your views here.
from django.shortcuts import render
from django.shortcuts import redirect
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from core.forms import ApplyPairForm, applyGroupForm, BreakPairForm
from django.contrib.auth.forms import AuthenticationForm

from core.models import (OtherConstraints, Pair, Student,
                         GroupConstraints,
                         LabGroup)

# Function that renders the login template
# or logs in an user
def student_login(request):
    context_dict = {}
    form = AuthenticationForm()
    context_dict['form'] = form
    # In case the user is already logged in
    if request.user.is_authenticated:
        # We get the info of the user who did the request
        user = Student.objects.get(username=request.user.username)

        context_dict['error'] = "You have to logOut"
        context_dict['first_name'] = user.first_name
        context_dict['last_name'] = user.last_name
        # Render ofthe template with the proper info
        return render(request, 'core/student_login.html', context=context_dict)
    # In case an user wants to log in
    elif request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        user = None
        if form.is_valid():
            # We get the data the user entered
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(username=username, password=password)

        context_dict['error'] = ""
        # If an user with that info exists
        if user:
            # If that user is valid we log in
            if user.is_active:
                login(request, user)
                # Redirect to the main page
                return redirect(reverse('core:home'))
            # In case it is not a valid user
            else:
                # devolver el login pero con ese mensaje de error
                context_dict['error'] = "You can't login with that account."
                return redirect(request,
                                'core/student_login.html',
                                context=context_dict)
        # If there is no user with that info
        else:
            print("Invalid login details")
            context_dict['error'] = "You entered an invalid"
            context_dict['error'] += " username or password."
            # Render of the login page with an error msg
            return render(request,
                          'core/student_login.html', context=context_dict)
    # In case someone just wanted to get to the login page without being logged
    else:

        context_dict['msg'] = "Please login to access this web site"
        context_dict['error'] = ""
        return render(request, 'core/student_login.html', context=context_dict)

# Function that convalidates an users marks if possible
# It is required for a user to be logged in
@login_required
def convalidation(request):

    conv = True
    # We get the user who asked for it
    user = Student.objects.get(username=request.user.username)
    gradeTheory = user.gradeTheoryLastYear
    gradeLab = user.gradeLabLastYear
    context_dict = {}
    context_dict['theoryGrade'] = gradeTheory
    context_dict['labGrade'] = gradeLab
    # Default msg that will change in case it is succesful
    context_dict['msg'] = "do not satisfy the requeriments for convalidation"
    pair = Pair.objects.filter(student1=user)
    # We check user is not part of a validated
    # pair or is Sstudent1
    phrase = "Remember you can't be part of a Pair."
    if pair:
        conv = False
        context_dict['error'] = phrase
    else:
        pair = Pair.objects.filter(student2=user)
        if pair:

            if pair[0].validated is True:
                conv = False
                context_dict['error'] = phrase
    # If the user is not part of a pair we enter in the if
    if conv is True:

        oc = OtherConstraints.objects.filter().first()
        # In case their grades are higher than the
        # requireds for convalidation
        if oc.minGradeLabConv <= gradeLab\
           and oc.minGradeTheoryConv <= gradeTheory:
            user.convalidationGranted = True
            user.save()
            # We change the msg to the success one
            context_dict['msg'] = "satify the requeriments for convalidation"
    # We render convalidation template with the proper info
    return render(request, 'core/convalidation.html', context=context_dict)


# Function that logsout a user
# It is needed for a user to be logged in
@login_required
def student_logout(request):
    logout(request)
    return render(request, 'core/student_logout.html')


# Function that renders the home page
# LogIn is not required
def home(request):
    # In case an user is authenticated
    if request.user.is_authenticated:
        # We get the user who requested the page
        user = Student.objects.get(username=request.user.username)
        # We get the users information
        context_dict = {}
        context_dict['first_name'] = user.first_name
        context_dict['lastname'] = user.last_name
        context_dict['lg'] = None
        if user.labGroup:
            context_dict['lg'] = True
            context_dict['labGroup'] = str(user.labGroup)
        context_dict['theoryGroup'] = str(user.theoryGroup)
        context_dict['pair'] = None
        context_dict['validated'] = None
        if user.convalidationGranted is True:
            context_dict['convalidationGranted'] = True
        else:
            context_dict['convalidationGranted'] = None
        # We check if the user has a pair
        p = Pair.objects.filter(student1=user)

        if p:
            pair = p[0]
        else:
            pair = None

        if pair:
            context_dict['pair'] = True
            s2 = pair.student2
            context_dict['pairmate'] = str(s2.first_name) + (" " +
                                                             str(s2.last_name))
            if pair.validated is True:
                context_dict['validated'] = True
            else:
                context_dict['student2'] = str(s2)
        else:
            p = Pair.objects.filter(student2=user)
            if p:
                pair = p[0]
            else:
                pair = None
            if pair:
                context_dict['pair'] = True
                s1 = pair.student1
                context_dict['pairmate'] = str(s1.first_name)
                context_dict['pairmate'] += " " + str(s1.last_name)
                if pair.validated is True:
                    context_dict['validated'] = True
                else:
                    context_dict['student2'] = str(user)
            else:
                context_dict['p'] = "NOT "
        # We render home with the users info
        return render(request, 'core/home.html', context=context_dict)
    else:
        # We render Home without an user info
        return render(request, 'core/home.html')


# Funcion for getting a pair
# LogIn is required
@login_required
def applypair(request):

    context_dict = {}
    form = ApplyPairForm(user=request.user)
    context_dict['error'] = ""
    user1 = Student.objects.get(username=request.user.username)
    solicitud = True
    sol = True
    # We check if the user who did the post
    # Was already part of a validated pair or
    # an student1 in another so he can not
    # do another pair request solicitud = False
    pair = Pair.objects.filter(student1=user1)
    pair2 = Pair.objects.filter(student2=user1)
    context_dict['msg'] = "Select the second member of your pair"
    if user1.convalidationGranted is True:
        context_dict['error2'] = "You have convalidated your Lab grades"
        solicitud = False
    if pair:
        solicitud = False
        context_dict['error'] = "User has already selected a pair"
        context_dict['msg'] = ""

    if pair2:
        p = pair2[0]
        if p.validated is True:
            solicitud = False
            context_dict['error'] = "User has already selected a pair"
            context_dict['msg'] = ""
    # In case the user did a post and solicitud can be done
    if request.method == 'POST' and solicitud is True:
        form = ApplyPairForm(request.POST, user=request.user)
        if form.is_valid():
            id2 = form.cleaned_data['secondMemberGroup']

            user2 = Student.objects.get(id=id2)
            pair = Pair.objects.filter(student1=user2, student2=user1)
            if pair:
                pair[0].validated = True
                pair[0].save()
            else:
                # In case the pair is gonna be created
                # we have to check if the user2 selected
                # is part of another pair as student1 because
                # if it gets here is becaus he would be student1
                # but user1 is not student2 so he should not
                # be able to choose him if that happens sol=False
                pair = Pair.objects.filter(student1=user2)
                pair2 = Pair.objects.filter(student2=user2)
                if pair:
                    sol = False
                    context_dict['error'] = "User has already selected a pair"
                    context_dict['msg'] = ""

                if sol is True:
                    form = ApplyPairForm(user=request.user)
                    pair = Pair.objects.get_or_create(student1=user1,
                                                      student2=user2,
                                                      validated=False)[0]
                    pair.save()
    # Info of the current user that is part of the pair
    context_dict['first_name'] = user1.first_name
    context_dict['last_name'] = user1.last_name
    context_dict['forms'] = form
    return render(request, 'core/applypair.html', context=context_dict)


# Function for breaking a pair
# Log In required
@login_required
def breakpair(request):

    user1 = Student.objects.get(username=request.user.username)
    context_dict = {}
    form = BreakPairForm(user=request.user)
    # In case the student ask for breaking a pair
    if request.method == 'POST':
        form = BreakPairForm(request.POST, user=request.user)
        if form.is_valid():
            idp = form.cleaned_data['pair']
            # We get the pair user wants to break
            par = Pair.objects.filter(id=idp)
            solicitud = True
            if par:
                pareja = par[0]

                st1 = pareja.student1
                st2 = pareja.student2
                lg1 = st1.labGroup
                lg2 = st2.labGroup
                if lg1 is None and lg2 is None:
                    solicitud = True
                # In case they are already in a labgroup
                # they can not break the pair solicitud is false
                else:
                    solicitud = False
                    # Error message for the template
                    phrase = "You can not delete that pair."
                    phrase += " You have already chosen a labGroup."
                    context_dict['error'] = phrase
                # In case solicitud is true
                if solicitud is True:
                    # We check if the pair is not validated yet
                    if pareja.validated is False:
                        # We delete the pair
                        pareja.delete()
                        context_dict['msg'] = "Your pair has been\
                                                successfully deleted"
                        form = BreakPairForm(user=request.user)
                    # In case the pair is validated
                    else:
                        st = pareja.studentBreakRequest
                        # We check if someone asked for breaking
                        # this pair before
                        # In case no one did it
                        if st is None:
                            # We set break request to the actual user
                            pareja.studentBreakRequest = user1
                            pareja.save()
                            context_dict['msg'] = "You have to wait \
                                                   until your mate \
                                                   asks it too."
                        else:
                            # In case someone did it we check if it was
                            # The other student of the pair
                            # In that case we delete the pair
                            if st is not user1:
                                pareja.delete()
                                context_dict['msg'] = "Your pair has\
                                                       been \
                                                       successfully deleted."
                                form = BreakPairForm(user=request.user)
        else:
            context_dict['error'] = "Could not process your request"

    context_dict['forms'] = form
    # Render of the template with the proper info in the context_dict
    return render(request, 'core/breakPair.html', context=context_dict)


# Function for choosing group
# logIn required
@login_required
def applygroup(request):
    context_dict = {}
    form = applyGroupForm(request.POST)
    context_dict['forms'] = form
    context_dict['error'] = ""
    user1 = Student.objects.get(username=request.user.username)
    tg = user1.theoryGroup
    gc = GroupConstraints.objects.filter(theoryGroup=tg)
    labgroups = LabGroup.objects.filter()
    context_dict['labGroups'] = []
    labGroupsAvailable = []
    # We put the groups of the select in a list
    for labg in labgroups:
        if labg.counter < labg.maxNumberStudents:
            labGroupsAvailable.append(labg)
    # We put the list of groups in the dict
    context_dict['labGroups'] = labGroupsAvailable
    oc = OtherConstraints.objects.filter()[0]
    # We check if the choosing group is available
    # for that the actualtime has to be equal or bigger
    # than the specified time in otherconstraints
    fechaActual = timezone.now()
    if oc.selectGroupStartDate > fechaActual:
        day = oc.selectGroupStartDate.day
        month = oc.selectGroupStartDate.month
        year = oc.selectGroupStartDate.year
        # In case it is not available we print the date when it will be
        context_dict['err'] = "You can't choose a labGroup until " + str(
                                    '{}-{}-{}'.format(day, month, year))
        context_dict['msg'] = "Group selection is not active"
        return render(request,
                      'core/applygroup.html', context=context_dict)
    # If it is time to choose
    else:
        context_dict['msg'] = "Select the group you want to join to"
    # If the user did a post for choosingthe group
    if request.method == 'POST':

        if form.is_valid():

            lgid = form.cleaned_data['labGroup']
            actualLg = user1.labGroup
            lg = LabGroup.objects.get(id=lgid)
            # We get the groupConstraints of the students labgroup chosen
            # and the users theorygroup
            gc = GroupConstraints.objects.filter(theoryGroup=tg, labGroup=lg)
            if gc:
                # We add the group to the student
                # and add the counter of students in the labgroup
                if lg.counter < lg.maxNumberStudents:
                    lg.counter += 1
                    user1.labGroup = lg
                    user1.save()
                    lg.save()
    # In case the user was already in a lab group we take him out
                    if actualLg:
                        actualLg.counter -= 1
                        actualLg.save()
    # If user1 is part of a validated pair we add his pairmate to the group
                pair1 = Pair.objects.filter(student1=user1)
                if pair1:
                    p = pair1[0]
                    if p.validated is True:
                        user2 = p.student2
                        if lg.counter < lg.maxNumberStudents:
                            lg.counter += 1
                            user2.labGroup = lg
                            user2.save()
                            lg.save()
                        # If student2 was already in a group we take him out
                            if actualLg:
                                actualLg.counter -= 1
                                actualLg.save()
                pair2 = Pair.objects.filter(student2=user1)
                if pair2:
                    p = pair2[0]
                    if p.validated is True:
                        user2 = p.student1
                        if lg.counter < lg.maxNumberStudents:
                            lg.counter += 1
                            user2.labGroup = lg
                            user2.save()
                            lg.save()
                        # If student2 was already in a group we take him out
                            if actualLg:
                                actualLg.counter -= 1
                                actualLg.save()
            else:
                # Error msg in case it is not possible to join to the labgroup
                # bc user is not of the correct theorygroup
                context_dict['error'] = "You can't\
                        choose that labgroup because you\
                        are not part of the theoryGroup"
    return render(request, 'core/applygroup.html', context=context_dict)


# Help views
# We render the templates with help info
# They will be available from the home page
# When no user is loggedIn
def login_help(request):
    return render(request, 'core/login_help.html')


def convalidation_help(request):
    return render(request, 'core/convalidation_help.html')


def partner_help(request):
    return render(request, 'core/partner_help.html')


def group_help(request):
    gc = OtherConstraints.objects.filter()
    context_dict = {}
    if gc.count() > 0:
        g = gc[0]
        context_dict['startdate'] = g.selectGroupStartDate
    context_dict['currentdate'] = timezone.now

    return render(request, 'core/group_help.html', context=context_dict)
