from django.test import TestCase
from django.test import Client
from datetime import timedelta
from django.utils import timezone
from core.models import (Student, Pair,
                         OtherConstraints)
from core.management.commands.populate import Command
import os
import django
django.setup()

os.environ.setdefault('DJANGO_SETTINGS_MODULE',
                      'labassign.settings')


class QueryTests(TestCase):

    def setUp(self):
        self.client = Client()
        # load Command class from populate
        c = Command()
        # execute populate
        c.handle(model='all', studentinfo='19-edat_psi.csv',
                 studentinfolastyear='19-edat_2_psi.csv')

    def test_query(self):

        user_1000 = get_Student(1000)
        if user_1000 is None:
            user_1000 = Student.objects.create(id=1000)
        print(user_1000)
        user_1001 = get_Student(1001)
        if user_1001 is None:
            user_1001 = Student.objects.create(id=1001)
        print(user_1001)
        pair = Pair.objects.get_or_create(student1=user_1000,
                                          student2=user_1001)[0]
        print(str(pair))
        pairsUser1000 = Pair.objects.filter(student1=user_1000)
        print("Parejas de user1000:\n")
        for p in pairsUser1000:
            print(str(p))
            p.validated = True
            print("Validated Modificado: "+str(p.validated)+"\n")

        sgsd = timezone.now() + timedelta(days=1)
        oc = OtherConstraints.objects.create(selectGroupStartDate=sgsd)
        oc.save()
        print("Nuevo otherconstraints: ")
        print(oc)

        oc = OtherConstraints.objects.filter()[0]
        fechaActual = timezone.now()
        if(oc.selectGroupStartDate < fechaActual):
            print(str(oc.selectGroupStartDate) +
                  "Está en el pasado.\nFecha Actual: " +
                  str(fechaActual))
        else:
            print(str(oc.selectGroupStartDate) +
                  "Está en el futuro.\nFecha Actual: " +
                  str(fechaActual))


def get_Student(id):
    try:
        s = Student.objects.get(id=id)
    except Student.DoesNotExist:
        s = None
    return s
