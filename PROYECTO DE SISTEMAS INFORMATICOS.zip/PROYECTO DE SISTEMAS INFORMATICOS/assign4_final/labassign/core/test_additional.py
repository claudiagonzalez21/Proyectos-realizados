from django.utils import timezone
from django.test import Client, TestCase
from django.urls import reverse

from core.management.commands.populate import Command
from core.models import (Student, OtherConstraints,
                         Pair, TheoryGroup,
                         LabGroup)


class AdditionalTests(TestCase):
    """Test that populate  has been saved data properly
       require files XXXX.pkl stored in the same directory that manage.py"""
    def setUp(self):
        self.client = Client()
        # load Command class from populate
        c = Command()
        # execute populate
        c.handle(model='all', studentinfo='19-edat_psi.csv',
                 studentinfolastyear='19-edat_2_psi.csv')
        self.client1 = self.client
        self.client2 = Client()
        self.client3 = Client()
        self.populate = Command()

    def tearDown(self):
        self.populate.cleanDataBase()

    @classmethod
    def loginTestUser(cls, client, user):
        client.force_login(user)

    @classmethod
    def decode(cls, txt):
        return txt.decode("utf-8")

    @classmethod
    def logoutTestUser(cls, client):
        client.logout()

    def test_logIn(self):
        """Student already loggedIn error msg You have to logOut"""
        user1 = Student.objects.get(id=1000)
        session = {"client": self.client1, "user": user1}

        self.loginTestUser(session["client"], session["user"])

        response = session["client"].get(reverse(
                                        'core:student_login'), follow=True)
        self.assertTrue(self.decode(response.content).find(
                                    "You have to logOut") != -1)

        self.logoutTestUser(session["client"])

        """In case you try to log in \
        with a non existing username or password"""
        data = {'username': "1234", 'password': "password"}
        phrase = "You entered an invalid username or password."
        response2 = self.client1.post(reverse(
                                    'core:student_login'),
                                    data=data, follow=True)
        self.assertTrue(self.decode(
                                    response2.content).find(phrase) != -1)

        """In case you try to log in with a non valid user
        user1 = Student.objects.get(id=1000)
        session = {"client": self.client1, "user": user1}
        data={'username':"464353", 'password':"297596"}
        user1.is_active = False
        user1.save()
        response3 = self.client1.post(reverse('core:student_login'),
                                         data=data,
                                         follow=True)
        self.assertTrue(self.decode(response3.content).
                         find("You can't login with that account.") != -1)
        user1.is_active = True
        user1.save()"""

    def test_Home(self):
        """Student already loggedIn error msg You have to logOut"""
        user1 = Student.objects.get(id=1000)
        session = {"client": self.client1, "user": user1}
        self.loginTestUser(session["client"], session["user"])

        """Home page in case the user has a labgroup"""
        user1.labGroup = LabGroup.objects.filter()[0]
        user1.save()
        response = session["client"].get(reverse('core:home'),
                                         follow=True)
        self.assertTrue(self.decode(response.content).
                        find(str(user1.labGroup)) != -1)

        """Home page in case the user has convalidation Granted = True"""
        user1.convalidationGranted = True
        user1.save()
        response = session["client"].get(reverse('core:home'),
                                         follow=True)
        self.assertTrue(self.decode(response.content).
                        find(
                             "Your lab assignments have been convalidated.")
                        != -1)

        """Home page in case a pair is validated"""
        user2 = Student.objects.get(id=1100)
        p = Pair.objects.get_or_create(student1=user1, student2=user2)[0]
        p.validated = True
        p.save()
        response = session["client"].get(reverse('core:home'),
                                         follow=True)
        self.assertTrue(self.decode(response.content).
                        find("The pair has been validated") != -1)

        """Home for the student2 of a pair"""
        self.logoutTestUser(session["client"])
        session = {"client": self.client2, "user": user2}
        self.loginTestUser(session["client"], session["user"])
        response = session["client"].get(reverse('core:home'),
                                         follow=True)
        self.assertTrue(self.decode(response.content).
                        find("The pair has been validated") != -1)

        """Home page in case a pair is NOT validated"""
        p = Pair.objects.get_or_create(student1=user1, student2=user2)[0]
        p.validated = False
        p.save()
        response = session["client"].get(reverse('core:home'),
                                         follow=True)
        self.assertTrue(self.decode(response.content).
                        find(str(user2) + " has to validate it.") != -1)

        """Home when there is no user"""
        self.logoutTestUser(session["client"])
        response = self.client1.get(reverse('core:home'),
                                    follow=True)
        self.assertTrue(self.decode(response.content).
                        find("Help") != -1)

    def test_help(self):
        response = self.client1.get(reverse('core:login_help'),
                                    follow=True)
        self.assertTrue(self.decode(response.content).
                        find("Login Help") != -1)

        response = self.client1.get(reverse('core:convalidation_help'),
                                    follow=True)
        self.assertTrue(self.decode(response.content).
                        find("Convalidation Help") != -1)

        response = self.client1.get(reverse('core:partner_help'),
                                    follow=True)
        self.assertTrue(self.decode(response.content).
                        find("Apply Pair help") != -1)

        response = self.client1.get(reverse('core:group_help'),
                                    follow=True)
        self.assertTrue(self.decode(response.content).
                        find("Apply Group help") != -1)

    def test_Group(self):
        """In case someone wants to join to a group
         but was already part of another one"""
        oc = OtherConstraints.objects.filter()[0]
        oc.selectGroupStartDate = timezone.now()
        oc.save()
        user1 = Student.objects.get(id=1000)
        session = {"client": self.client1, "user": user1}
        self.loginTestUser(session["client"], session["user"])
        user1.theoryGroup = TheoryGroup.objects.get(id=126)
        labg = LabGroup.objects.get(id=1261)
        user1.labGroup = labg
        user1.save()
        labg.counter += 1
        pair = Pair.objects.filter(student1=user1)[0]
        pair.validated = True
        pair.save()
        pair.student2.labGroup = labg
        labg.counter += 1
        labg.save()
        count = labg.counter - 2
        pair.student2.save()
        id2 = pair.student2.id
        lg = LabGroup.objects.get(id=1262)
        data = {'labGroup': lg.id}

        session["client"].post(reverse('core:applygroup'),
                               data=data,
                               follow=True)
        self.assertTrue(Student.objects.filter(id=1000, labGroup=lg).exists())
        self.assertTrue(Student.objects.filter(id=id2, labGroup=lg).exists())
        self.assertEqual(LabGroup.objects.get(id=1261).counter, count)
        self.logoutTestUser(session["client"])
        """In case the one logged In is the student2 in the pair"""

        user2 = Student.objects.get(id=id2)
        session = {"client": self.client1, "user": user2}
        self.loginTestUser(session["client"], session["user"])
        user2.theoryGroup = TheoryGroup.objects.get(id=126)
        user2.save()
        labg = LabGroup.objects.get(id=1262)
        pair = Pair.objects.filter(student2=user2)[0]
        pair.validated = True
        pair.save()
        count = labg.counter - 2
        lg = LabGroup.objects.get(id=1261)
        data = {'labGroup': lg.id}

        session["client"].post(reverse('core:applygroup'),
                               data=data,
                               follow=True)
        self.assertTrue(Student.objects.filter(id=id2, labGroup=lg).exists())
        self.assertTrue(Student.objects.filter(id=1000, labGroup=lg).exists())
        self.assertEqual(LabGroup.objects.get(id=1262).counter, count)
        self.logoutTestUser(session["client"])

    def test_Pair(self):

        user = Student.objects.get(id=1002)
        session = {"client": self.client1, "user": user}
        self.loginTestUser(session["client"], session["user"])

        id2 = 1000  # Usuario con una pareja ya creada
        data = {'secondMemberGroup': id2}

        response = session["client"].post(reverse('core:applypair'),
                                          data=data,
                                          follow=True)
        self.assertTrue(self.decode(response.content).
                        find("User has already selected a pair") != -1)

        self.logoutTestUser(session["client"])
        """In case The logged in user is student2 in a validated pair"""
        user1 = Student.objects.get(id=1000)
        user2 = Student.objects.get(id=1100)
        session = {"client": self.client1, "user": user2}
        self.loginTestUser(session["client"], session["user"])
        pair = Pair.objects.get(student1=user1, student2=user2)
        pair.validated = True
        pair.save()

        id2 = 1013
        data = {'secondMemberGroup': id2}

        response = session["client"].post(reverse('core:applypair'),
                                          data=data,
                                          follow=True)
        self.assertTrue(self.decode(response.content).
                        find("User has already selected a pair") != -1)
        self.logoutTestUser(session["client"])

        """In case grades are convalidated"""
        user = Student.objects.get(id=1130)
        session = {"client": self.client1, "user": user}
        self.loginTestUser(session["client"], session["user"])

        user.convalidationGranted = True
        user.save()
        id2 = 1132
        data = {'secondMemberGroup': id2}

        response = session["client"].post(reverse('core:applypair'),
                                          data=data,
                                          follow=True)
        self.assertTrue(self.decode(response.content).
                        find("You have convalidated your Lab grades") != -1)

        self.logoutTestUser(session["client"])

    def test_BreakPair(self):

        user = Student.objects.get(id=1124)
        user2 = Student.objects.get(id=1125)
        pair = Pair.objects.get_or_create(student1=user,
                                          student2=user2,
                                          validated=False)[0]

        lg = LabGroup.objects.get(id=1201)

        user.labGroup = lg
        user.save()
        user2.labGroup = lg
        user.save()

        session = {"client": self.client1, "user": user}
        self.loginTestUser(session["client"], session["user"])

        idp = pair.id
        data = {'pair': idp}

        response = session["client"].post(reverse('core:breakpair'),
                                          data=data,
                                          follow=True)
        phrase = "You can not delete that pair."
        phrase += " You have already chosen a labGroup."
        self.assertTrue(self.decode(response.content).
                        find(phrase) != -1)
