from django.urls import path
from core import views

app_name = 'core'
urlpatterns = [
    path('', views.home, name='home'),
    path('student_login/', views.student_login, name='student_login'),
    path('student_logout/', views.student_logout, name='student_logout'),
    path('convalidation/', views.convalidation, name='convalidation'),
    path('applypair/', views.applypair, name='applypair'),
    path('breakpair/', views.breakpair, name='breakpair'),
    path('applygroup/', views.applygroup, name='applygroup'),
    path('login_help/', views.login_help, name='login_help'),
    path('convalidation_help/', views.convalidation_help,
         name='convalidation_help'),
    path('group_help/', views.group_help, name='group_help'),
    path('partner_help/', views.partner_help, name='partner_help'),
]
