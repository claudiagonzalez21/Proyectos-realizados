from django import forms
from core.models import (Pair, Student, LabGroup)


# Form for the select of creating a pair
class ApplyPairForm(forms.Form):
    secondMemberGroup = forms.ChoiceField(choices=[],
                                          label="Students")

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super(ApplyPairForm, self).__init__(*args, **kwargs)
        lista = []
        st = []
        st = Student.objects.all().exclude(username=self.user.username)
        # We add to the options all the students form non validated pairs
        for s in st:
            p = Pair.objects.filter(student1=s)
            if not p:
                p = Pair.objects.filter(student2=s)
                if not p:
                    lista.append(s)
                else:
                    pair = p[0]
                    v = pair.validated
                    if v is False:
                        lista.append(s)
            else:
                pair = p[0]
                v = pair.validated
                if v is False:
                    lista.append(s)
        lista2 = []
        for s in lista:
            lista2.append((s.id, s.last_name + "," + s.first_name))
        self.fields['secondMemberGroup'].choices = lista2


# Form for the select of pairs for breaking one
class BreakPairForm(forms.Form):
    pair = forms.ChoiceField(choices=[])

    def __init__(self, *args, **kwargs):

        self.user = kwargs.pop('user', None)
        super(BreakPairForm, self).__init__(*args, **kwargs)

        # We add to the options all the pairs the current student is part of
        pairs = []
        p = Pair.objects.filter(student1=self.user)
        p2 = Pair.objects.filter(student2=self.user)
        if p:
            for pareja in p:
                pairs.append(pareja)
        if p2:
            for pareja in p2:
                pairs.append(pareja)

        lista = []
        for s in pairs:
            lista.append((s.id, "Student1=" + str(s.student1)
                          + " Student2= "
                          + str(s.student2)
                          + " Status= "
                          + str(s.validated)))

        self.fields['pair'].choices = lista


# Form for the select of choosing a labgroup
class applyGroupForm(forms.Form):
    labGroup = forms.ChoiceField(choices=[])

    def __init__(self, *args, **kwargs):
        super(applyGroupForm, self).__init__(*args, **kwargs)
        lista = []

        labgroups = LabGroup.objects.filter()
        labGroupsAvailable = []
    # Guardamos los grupos que van a aparecer en el desplegable
        for labg in labgroups:
            if labg.counter < labg.maxNumberStudents:
                labGroupsAvailable.append(labg)

        for i in labGroupsAvailable:
            lista.append((i.id, i.groupName))

        self.fields['labGroup'].choices = lista
