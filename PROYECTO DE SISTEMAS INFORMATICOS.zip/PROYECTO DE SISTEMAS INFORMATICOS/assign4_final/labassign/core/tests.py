# Uncoment the lines to execute step-by-step each test-set

from core.tests_models import ModelTests
from core.tests_services import (ServiceBaseTest,
                                 LogInOutServiceTests,
                                 ConvalidationServiceTests,
                                 PairServiceTests,
                                 GroupServiceTests)
from core.test_query import QueryTests
from core.test_additional import AdditionalTests
