from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User


#  Create your models here.


class Teacher(models.Model):
    first_name = models.CharField(max_length=128, default=None)
    last_name = models.CharField(max_length=128, default=None)

    def save(self, *args, **kwargs):
        super(Teacher, self).save(*args, **kwargs)

    class Meta:
        ordering = ('last_name', 'first_name', )
        #  imprimir en orden de last_name,first_name

    def __str__(self):
        return self.first_name


class TheoryGroup(models.Model):
    groupName = models.CharField(max_length=128, unique=True, null=True)
    language = models.CharField(max_length=128, unique=False, null=True)

    def save(self, *args, **kwargs):
        super(TheoryGroup, self).save(*args, **kwargs)

    class Meta:
        ordering = ('groupName', )
        #  imprimir en orden de last_name,first_name

    def __str__(self):
        return self.groupName


class LabGroup(models.Model):
    teacher = models.ForeignKey(Teacher,
                                on_delete=models.CASCADE,
                                default=None, blank=True,
                                null=True)
    groupName = models.CharField(max_length=128,
                                 default=None,
                                 blank=True, null=True)
    language = models.CharField(max_length=128,
                                default=None,
                                blank=True, null=True)
    schedule = models.CharField(max_length=128,
                                default=None,
                                blank=True, null=True)
    maxNumberStudents = models.IntegerField(default=0)
    counter = models.IntegerField(default=0)

    def save(self, *args, **kwargs):
        super(LabGroup, self).save(*args, **kwargs)

    class Meta:
        ordering = ('groupName', )
    #  imprimir en orden de last_name,first_name

    def __str__(self):
        return self.groupName


class Student(User):
    labGroup = models.ForeignKey(LabGroup,
                                 on_delete=models.CASCADE,
                                 default=None, null=True)
    theoryGroup = models.ForeignKey(TheoryGroup,
                                    on_delete=models.CASCADE,
                                    default=None, null=True)

    gradeTheoryLastYear = models.FloatField(default=0.0,
                                            null=True)
    gradeLabLastYear = models.FloatField(default=0.0, null=True)
    convalidationGranted = models.BooleanField(default=False)

    class Meta:
        ordering = ('last_name', 'first_name',)
        #  imprimir en orden de last_name,first_name

    def __str__(self):
        return self.first_name + " " + self.last_name


class OtherConstraints(models.Model):
    #  ver lo de la primary key (id)
    selectGroupStartDate = models.DateTimeField(
                                                default=timezone.now,
                                                blank=True)
    minGradeTheoryConv = models.FloatField(default=None, null=True)
    minGradeLabConv = models.FloatField(default=None, null=True)

    def save(self, *args, **kwargs):
        super(OtherConstraints, self).save(*args, **kwargs)

    def __str__(self):
        aux1 = str(self.selectGroupStartDate) + " "
        aux2 = str(self.minGradeTheoryConv) + " "
        return aux1 + aux2 + str(self.minGradeLabConv)


class Pair(models.Model):
    student1 = models.ForeignKey(Student,
                                 related_name='%(class)sStudent1',
                                 on_delete=models.CASCADE)
    student2 = models.ForeignKey(Student,
                                 related_name='%(class)sStudent2',
                                 on_delete=models.CASCADE,
                                 null=True)
    validated = models.BooleanField(default=False)
    studentBreakRequest = models.ForeignKey(Student,
                                            on_delete=models.CASCADE,
                                            null=True)

    def save(self, *args, **kwargs):
        super(Pair, self).save(*args, **kwargs)

    def __str__(self):
        return str(self.student1) + ", " + str(self.student2)


class GroupConstraints(models.Model):
    theoryGroup = models.ForeignKey(TheoryGroup,
                                    related_name='%(class)stheorygroup',
                                    on_delete=models.CASCADE,
                                    default=None)
    labGroup = models.ForeignKey(LabGroup,
                                 related_name='%(class)slabgroup',
                                 on_delete=models.CASCADE,
                                 default=None)

    def save(self, *args, **kwargs):
        super(GroupConstraints, self).save(*args, **kwargs)

    class Meta:
        ordering = ('labGroup',)
        # imprimir en orden de labgroup

    def __str__(self):
        return self.theoryGroup.groupName + " " + self.labGroup.groupName
