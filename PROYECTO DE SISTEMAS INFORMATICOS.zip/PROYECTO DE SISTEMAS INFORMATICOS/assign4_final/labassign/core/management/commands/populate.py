# Populate database
# This file has to be placed within the
# core/management/commands directory in your project.
# If that directory doesn't exist, create it.
# The name of the script is the name of the custom command,
# that is, populate.py.
#
# execute python manage.py  populate


from django.core.management.base import BaseCommand
from core.models import (OtherConstraints, Pair, Student,
                         GroupConstraints, TheoryGroup,
                         LabGroup, Teacher)
import os
import csv
import collections
from django.utils import timezone
from datetime import timedelta
import django
django.setup()

os.environ.setdefault('DJANGO_SETTINGS_MODULE',
                      'labassign.settings')

maxNumberStudents = 23
# The name of this class is not optional must be Command
# otherwise manage.py will not process it properly
#
# Teachers, groups and constraints
# will be hardcoded in this file.
# Students will be read from a cvs file
# last year grade will be obtained from another cvs file


class Command(BaseCommand):

    # helps and arguments shown when command python manage.py help populate
    # is executed.
    help = """populate database
           """

    def add_arguments(self, parser):
        parser.add_argument('model', type=str, help="""
        model to  update:
        all -> all models
        teacher
        labgroup
        theorygroup
        groupconstraints
        otherconstrains
        student (require csv file)
        studentgrade (require different csv file,
        update only existing students)
        pair
        """)
        parser.add_argument('studentinfo', type=str, help="""CSV file with student information
        header= NIE, DNI, Apellidos, Nombre, Teoría
        if NIE or DNI == 0 skip this entry and print a warning""")
        parser.add_argument('studentinfolastyear', type=str, help="""CSV file with student information
        header= NIE,DNI,Apellidos,Nombre,Teoría, grade lab, grade the
        if NIE or DNI == 0 skip this entry and print a warning""")

    # handle is another compulsory name, do not change it"
    def handle(self, *args, **kwargs):
        model = kwargs['model']
        cvsStudentFile = kwargs['studentinfo']
        cvsStudentFileGrades = kwargs['studentinfolastyear']
        # clean database
        if model == 'all':
            self.cleanDataBase()
        if model == 'teacher' or model == 'all':
            self.teacher()
        if model == 'labgroup' or model == 'all':
            self.labgroup()
        if model == 'theorygroup' or model == 'all':
            self.theorygroup()
        if model == 'groupconstraints' or model == 'all':
            self.groupconstraints()
        if model == 'otherconstrains' or model == 'all':
            self.otherconstrains()
        if model == 'student' or model == 'all':
            self.student(cvsStudentFile)
        if model == 'studentgrade' or model == 'all':
            self.studentgrade(cvsStudentFileGrades)
        if model == 'pair' or model == 'all':
            self.pair()

    def cleanDataBase(self):

        Teacher.objects.all().delete()
        Student.objects.all().delete()
        LabGroup.objects.all().delete()
        TheoryGroup.objects.all().delete()
        GroupConstraints.objects.all().delete()
        OtherConstraints.objects.all().delete()
        Pair.objects.all().delete()

    def teacher(self):
        teacherD = [
            {'id': 1,  # 1261, L 18:00, 1271 X 18-20
             'first_name': 'No',
             'last_name': 'Asignado1', },
            {'id': 2,  # 1262 X 18-20, 1263/1273 V 17-19
             'first_name': 'No',
             'last_name': 'Asignado4', },
            {'id': 3,  # 1272 V 17-19, 1291 L 18-20
             'first_name': 'Julia',
             'last_name': 'Diaz Garcia', },
            {'id': 4,  # 1292/1251V 17:00
             'first_name': 'Alvaro',
             'last_name': 'del Val Latorre', },
            {'id': 5,  # 1201 X 18:00
             'first_name': 'Roberto',
             'last_name': 'Marabini Ruiz', }]

        for t in teacherD:
            add_teacher(t['id'], t['first_name'], t['last_name'])

    def labgroup(self):
        labgroupD = [
            {'id': 1261,  # 1261, L 18:00, 1271 X 18-20
             'groupName': '1261',
             'teacher': 1,
             'schedule': 'Lunes/Monday 18-20',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1262,  # 1261, L 18:00, 1271 X 18-20
             'teacher': 2,
             'groupName': '1262',
             'schedule': 'Miércoles/Wednesday 18-20',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1263,  # 1261, L 18:00, 1271 X 18-20
             'teacher': 2,
             'groupName': '1263',
             'schedule': 'Viernes/Friday 17-19',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1271,  # 1261, L 18:00, 1271 X 18-20
             'teacher': 1,
             'groupName': '1271',
             'schedule': 'Miércoles/Wednesday 18-20',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1272,  # 1261, L 18:00, 1271 X 18-20
             'teacher': 3,
             'groupName': '1272',
             'schedule': 'Viernes/Friday 17-19',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1291,  # 1261, L 18:00, 1271 X 18-20
             'teacher': 3,
             'groupName': '1291',
             'schedule': 'Lunes/Monday 18-20',
             'language': 'inglés/English',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1292,
             'teacher': 4,
             'groupName': '1292',
             'schedule': 'Viernes/Friday 17-19',
             'language': 'inglés/English',
             'maxNumberStudents': maxNumberStudents},
            {'id': 1201,
             'teacher': 5,
             'groupName': '1201',
             'schedule': 'Miércoles/Wednesday 18-20',
             'language': 'español/Spanish',
             'maxNumberStudents': maxNumberStudents}]

        for lb in labgroupD:
            add_labgroup(lb['id'], lb['teacher'],
                         lb['groupName'], lb['schedule'],
                         lb['language'], lb['maxNumberStudents'])

    def theorygroup(self):
        theorygroupD = [
            {'id': 126,
             'groupName': '126',
             'language': 'español/Spanish', },
            {'id': 127,  # 127/120
             'groupName': '127',
             'language': 'español/Spanish', },
            {'id': 129,  # 129/125
             'groupName': '129',
             'language': 'inglés/English', },
            {'id': 120,  # 127/120
             'groupName': '120',
             'language': 'español/Spanish', },
            {'id': 125,  # 129/125
             'groupName': '125',
             'language': 'inglés/English', }]

        for tg in theorygroupD:
            add_theorygroup(tg['id'], tg['groupName'],
                            tg['language'])

    def groupconstraints(self):
        groupconstraintsD = [
            {'theoryGroup': 120, 'labGroup': 1201},
            {'theoryGroup': 126, 'labGroup': 1261},  # mañana
            {'theoryGroup': 126, 'labGroup': 1262},
            {'theoryGroup': 126, 'labGroup': 1263},
            {'theoryGroup': 127, 'labGroup': 1271},  # tarde
            {'theoryGroup': 127, 'labGroup': 1272},
            {'theoryGroup': 129, 'labGroup': 1291},
            {'theoryGroup': 125, 'labGroup': 1292}]

        for gc in groupconstraintsD:
            add_groupconstraints(gc['theoryGroup'], gc['labGroup'])

    def pair(self):
        """ create two requests
            1000 -> 1100
            1001 -> 1001
            create three verified groups
            1010 - 1110
            1011 - 1111
            1012 - 1112
        """
        pairD = collections.OrderedDict()
        # Mañana
        pairD[1000] = {'student2': 1100, 'validated': False}
        pairD[1001] = {'student2': 1101, 'validated': False}
        pairD[1010] = {'student2': 1110, 'validated': True}
        pairD[1011] = {'student2': 1111, 'validated': True}
        pairD[1012] = {'student2': 1112, 'validated': True}

        add_pair(pairD[1000]['student2'], pairD[1000]['validated'], 1000)
        add_pair(pairD[1001]['student2'], pairD[1001]['validated'], 1001)
        add_pair(pairD[1010]['student2'], pairD[1010]['validated'], 1010)
        add_pair(pairD[1011]['student2'], pairD[1011]['validated'], 1011)
        add_pair(pairD[1012]['student2'], pairD[1012]['validated'], 1012)

    def otherconstrains(self):
        selectGroupStartDate = timezone.now() + timedelta(days=1)
        minGradeTheoryConv = 3
        minGradeLabConv = 7
        add_otherContraints(selectGroupStartDate,
                            minGradeTheoryConv, minGradeLabConv)

    def student(self, csvStudentFile):
        f = open(csvStudentFile, newline='')
        student = csv.DictReader(f)
        id = 1000
        for s in student:
            add_student(s['NIE'], s['DNI'], s['Apellidos'],
                        s['Nombre'], s['grupo-teoria'], id)
            id += 1

    def studentgrade(self, cvsStudentFileGrades):
        f = open(cvsStudentFileGrades, newline='')
        student_grades = csv.DictReader(f)
        id = 1000
        for s in student_grades:
            add_studentgrade(s['NIE'], s['DNI'], s['Apellidos'],
                             s['Nombre'], s['grupo-teoria'],
                             s['nota-practicas'], s['nota-teoria'], id)
            id += 1


def add_teacher(id, first_name, last_name):
    t = Teacher.objects.get_or_create(id=id,
                                      first_name=first_name,
                                      last_name=last_name)[0]
    t.save()
    return t


def add_labgroup(id, teacher, groupName,
                 schedule, language, mns):
    lgteacher = Teacher.objects.get(id=teacher)

    lg = LabGroup.objects.get_or_create(id=id,
                                        teacher=lgteacher, groupName=groupName,
                                        schedule=schedule, language=language,
                                        maxNumberStudents=mns)[0]

    lg.save()
    return lg


def add_theorygroup(id, groupName, language):
    tg = TheoryGroup.objects.get_or_create(id=id,
                                           groupName=groupName,
                                           language=language)[0]

    tg.save()
    return tg


def add_groupconstraints(theorygroup, labgroup):

    tg = TheoryGroup.objects.get(id=theorygroup)
    lg = LabGroup.objects.get(id=labgroup)
    gc = GroupConstraints.objects.get_or_create(theoryGroup=tg, labGroup=lg)[0]
    gc.save()
    return gc


def add_pair(student, validated, id):
    st2 = Student.objects.get(id=student)
    st = Student.objects.get(id=student-100)
    p = Pair.objects.get_or_create(id=id, student1=st,
                                   student2=st2, validated=validated)[0]
    p.save()
    return p


def add_otherContraints(sgsd, mgt, mgl):
    oc = OtherConstraints.objects.get_or_create(
                                                selectGroupStartDate=sgsd,
                                                minGradeLabConv=mgl,
                                                minGradeTheoryConv=mgt
                                                )[0]

    oc.save()
    return oc


def add_student(nie, dni, apellidos, nombre, grupoTeoria, id):
    tg = TheoryGroup.objects.get(id=grupoTeoria)
    s = Student.objects.get_or_create(id=id, password=dni, username=nie,
                                      first_name=nombre, last_name=apellidos,
                                      theoryGroup=tg)[0]
    s.set_password(s.password)
    s.save()
    return s


def add_studentgrade(nie, dni, apellidos, nombre,
                     grupoTeoria, notaPracticas, notaTeoria, id):
    tg = TheoryGroup.objects.get(id=grupoTeoria)
    s = Student.objects.get(id=id, first_name=nombre, last_name=apellidos)
    s.theoryGroup = tg
    s.gradeTheoryLastYear = notaTeoria
    s.gradeLabLastYear = notaPracticas
    s.convalidationGranted = False
    s.save()
    return s
